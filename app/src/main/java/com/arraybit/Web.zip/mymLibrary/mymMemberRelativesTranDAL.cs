using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace mymLibrary
{
    /// <summary>
    /// Class for mymMemberRelativesTran
    /// </summary>
    public class mymMemberRelativesTranDAL
    {
        #region Properties
        public int MemberRelativesTranId { get; set; }
        public int linktoMemberMasterId { get; set; }
        public string RelativeName { get; set; }
        public string ImageName { get; set; }
        public string Gender { get; set; }
        public DateTime? BirthDate { get; set; }
        public string Relation { get; set; }

        /// Extra
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "MemberRelative/";
            if (sqlRdr.Read())
            {
                this.MemberRelativesTranId = Convert.ToInt32(sqlRdr["MemberRelativesTranId"]);
                this.linktoMemberMasterId = Convert.ToInt32(sqlRdr["linktoMemberMasterId"]);
                this.RelativeName = Convert.ToString(sqlRdr["RelativeName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);
                }
                this.Gender = Convert.ToString(sqlRdr["Gender"]);
                if (sqlRdr["BirthDate"] != DBNull.Value)
                {
                    this.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                }
                this.Relation = Convert.ToString(sqlRdr["Relation"]);

                /// Extra
                return true;
            }
            return false;
        }

        public List<mymMemberRelativesTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "MemberRelative/";
            List<mymMemberRelativesTranDAL> lstMemberRelativesTran = new List<mymMemberRelativesTranDAL>();
            mymMemberRelativesTranDAL objMemberRelativesTran = null;
            while (sqlRdr.Read())
            {
                objMemberRelativesTran = new mymMemberRelativesTranDAL();
                objMemberRelativesTran.MemberRelativesTranId = Convert.ToInt32(sqlRdr["MemberRelativesTranId"]);
                objMemberRelativesTran.linktoMemberMasterId = Convert.ToInt32(sqlRdr["linktoMemberMasterId"]);
                objMemberRelativesTran.RelativeName = Convert.ToString(sqlRdr["RelativeName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objMemberRelativesTran.ImageName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);
                }
                objMemberRelativesTran.Gender = Convert.ToString(sqlRdr["Gender"]);
                if (sqlRdr["BirthDate"] != DBNull.Value)
                {
                    objMemberRelativesTran.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                }
                objMemberRelativesTran.Relation = Convert.ToString(sqlRdr["Relation"]);

                /// Extra
                lstMemberRelativesTran.Add(objMemberRelativesTran);
            }
            return lstMemberRelativesTran;
        }
        #endregion

        #region Insert
        public mymRecordStatus InsertMemberRelativesTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("mymMemberRelativesTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberRelativesTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoMemberMasterId", SqlDbType.Int).Value = this.linktoMemberMasterId;
                SqlCmd.Parameters.Add("@RelativeName", SqlDbType.VarChar).Value = this.RelativeName;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@Relation", SqlDbType.VarChar).Value = this.Relation;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.MemberRelativesTranId = Convert.ToInt32(SqlCmd.Parameters["@MemberRelativesTranId"].Value);
                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {

            }
        }
        #endregion


        #region Delete
        public mymRecordStatus DeleteAllMemberRelativesTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("mymMemberRelativesTranbyMemberMasterId_DeleteAll", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoMemberMasterId", SqlDbType.Int).Value = this.linktoMemberMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                //mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                //mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectMemberRelativesTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberRelativesTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberRelativesTranId", SqlDbType.Int).Value = this.MemberRelativesTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<mymMemberRelativesTranDAL> SelectAllMemberRelativesTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberRelativesTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<mymMemberRelativesTranDAL> lstMemberRelativesTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMemberRelativesTranDAL;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<mymMemberRelativesTranDAL> SelectAllMemberRelativesTranbyMemberMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberRelativesTranbyMemberMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoMemberMasterId", SqlDbType.Int).Value = this.linktoMemberMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<mymMemberRelativesTranDAL> lstMemberRelativesTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMemberRelativesTranDAL;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
