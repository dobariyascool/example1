﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using mymLibrary;
using System.Data;

namespace mymLibrary
{
    public class mymErrorLogDAL
    {
        #region Properties
        public short ErrorLogId { get; set; }
        public DateTime ErrorDateTime { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorStackTrace { get; set; }
        #endregion

        #region Class Methods
        private List<mymErrorLogDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<mymErrorLogDAL> lstErrorLog = new List<mymErrorLogDAL>();
            mymErrorLogDAL objErrorLog = null;
            while (sqlRdr.Read())
            {
                objErrorLog = new mymErrorLogDAL();
                objErrorLog.ErrorLogId = Convert.ToInt16(sqlRdr["ErrorLogId"]);
                objErrorLog.ErrorDateTime = Convert.ToDateTime(sqlRdr["ErrorDateTime"]);
                objErrorLog.ErrorMessage = Convert.ToString(sqlRdr["ErrorMessage"]);
                objErrorLog.ErrorStackTrace = Convert.ToString(sqlRdr["ErrorStackTrace"]);
                lstErrorLog.Add(objErrorLog);
            }
            return lstErrorLog;
        }
        #endregion

        #region Insert
        public mymRecordStatus InsertErrorLog()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymErrorLog_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ErrorLogId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ErrorDateTime", SqlDbType.DateTime).Value = this.ErrorDateTime;
                SqlCmd.Parameters.Add("@ErrorMessage", SqlDbType.VarChar).Value = this.ErrorMessage;
                SqlCmd.Parameters.Add("@ErrorStackTrace", SqlDbType.VarChar).Value = this.ErrorStackTrace;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.ErrorLogId = Convert.ToInt16(SqlCmd.Parameters["@ErrorLogId"].Value);
                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch
            {
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public mymRecordStatus DeleteErrorLog()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymErrorLog_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ErrorLogId", SqlDbType.SmallInt).Value = this.ErrorLogId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static mymRecordStatus DeleteAllErrorLog(string ids)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymErrorLog_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ids", SqlDbType.VarChar).Value = ids;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }


        #endregion

        #region SelectAll
        public List<mymErrorLogDAL> SelectAllErrorLogPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymErrorLogPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<mymErrorLogDAL> lstErrorLogDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstErrorLogDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
