using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Class for mymNotificationMaster
	/// </summary>
	public class mymNotificationMasterDAL
	{
		#region Properties
		public int NotificationMasterId { get; set; }
		public string NotificationTitle { get; set; }
		public string NotificationText { get; set; }
		public string NotificationImageName { get; set; }
		public DateTime NotificationDateTime { get; set; }
		public DateTime CreateDateTime { get; set; }
		public int linktoMemberMasterIdCreatedBy { get; set; }
		public DateTime? UpdateDateTime { get; set; }
		public int? linktoMemberMasterIdUpdatedBy { get; set; }
		public bool IsDeleted { get; set; }

		
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Notification/";
			if (sqlRdr.Read())
			{
				this.NotificationMasterId = Convert.ToInt32(sqlRdr["NotificationMasterId"]);
				this.NotificationTitle = Convert.ToString(sqlRdr["NotificationTitle"]);
				this.NotificationText = Convert.ToString(sqlRdr["NotificationText"]);
                if (sqlRdr["NotificationImageName"] != DBNull.Value)
                {
                    this.NotificationImageName = ImageRetrievePath + Convert.ToString(sqlRdr["NotificationImageName"]);
                }
				this.NotificationDateTime = Convert.ToDateTime(sqlRdr["NotificationDateTime"]);
				this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				this.linktoMemberMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdCreatedBy"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoMemberMasterIdUpdatedBy"] != DBNull.Value)
				{
					this.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdUpdatedBy"]);
				}
				this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
		
				return true;
			}
			return false;
		}

		private List<mymNotificationMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Notification/";
			List<mymNotificationMasterDAL> lstNotificationMaster = new List<mymNotificationMasterDAL>();
			mymNotificationMasterDAL objNotificationMaster = null;
			while (sqlRdr.Read())
			{
				objNotificationMaster = new mymNotificationMasterDAL();
				objNotificationMaster.NotificationMasterId = Convert.ToInt32(sqlRdr["NotificationMasterId"]);
				objNotificationMaster.NotificationTitle = Convert.ToString(sqlRdr["NotificationTitle"]);
				objNotificationMaster.NotificationText = Convert.ToString(sqlRdr["NotificationText"]);
				objNotificationMaster.NotificationImageName = Convert.ToString(sqlRdr["NotificationImageName"]);
				objNotificationMaster.NotificationDateTime = Convert.ToDateTime(sqlRdr["NotificationDateTime"]);
				objNotificationMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				objNotificationMaster.linktoMemberMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdCreatedBy"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					objNotificationMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoMemberMasterIdUpdatedBy"] != DBNull.Value)
				{
					objNotificationMaster.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdUpdatedBy"]);
				}
				objNotificationMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
			
				lstNotificationMaster.Add(objNotificationMaster);
			}
			return lstNotificationMaster;
		}
		#endregion

		#region Insert
		public mymRecordStatus InsertNotificationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@NotificationTitle", SqlDbType.VarChar).Value = this.NotificationTitle;
				SqlCmd.Parameters.Add("@NotificationText", SqlDbType.VarChar).Value = this.NotificationText;
				SqlCmd.Parameters.Add("@NotificationImageName", SqlDbType.VarChar).Value = this.NotificationImageName;
				SqlCmd.Parameters.Add("@NotificationDateTime", SqlDbType.DateTime).Value = this.NotificationDateTime;
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
				SqlCmd.Parameters.Add("@linktoMemberMasterIdCreatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.NotificationMasterId = Convert.ToInt32(SqlCmd.Parameters["@NotificationMasterId"].Value);
				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public mymRecordStatus UpdateNotificationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Value = this.NotificationMasterId;
				SqlCmd.Parameters.Add("@NotificationTitle", SqlDbType.VarChar).Value = this.NotificationTitle;
				SqlCmd.Parameters.Add("@NotificationText", SqlDbType.VarChar).Value = this.NotificationText;
				SqlCmd.Parameters.Add("@NotificationImageName", SqlDbType.VarChar).Value = this.NotificationImageName;
				SqlCmd.Parameters.Add("@NotificationDateTime", SqlDbType.DateTime).Value = this.NotificationDateTime;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public mymRecordStatus DeleteNotificationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Value = this.NotificationMasterId;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectNotificationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationMasterId", SqlDbType.Int).Value = this.NotificationMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<mymNotificationMasterDAL> SelectAllNotificationMasterPageWise(short startRowIndex, short pageSize,short linktoMemberMasterId, out short totalRecords)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationMasterPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoMemberMasterId", SqlDbType.SmallInt).Value = linktoMemberMasterId;
				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<mymNotificationMasterDAL> lstNotificationMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstNotificationMasterDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				mymGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<mymNotificationMasterDAL> SelectAllNotificationMasterNotificationMasterId()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationMasterNotificationMasterId_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<mymNotificationMasterDAL> lstNotificationMasterDAL = new List<mymNotificationMasterDAL>();
				mymNotificationMasterDAL objNotificationMasterDAL = null;
				while (SqlRdr.Read())
				{
					objNotificationMasterDAL = new mymNotificationMasterDAL();
					objNotificationMasterDAL.NotificationMasterId = Convert.ToInt32(SqlRdr["NotificationMasterId"]);
					lstNotificationMasterDAL.Add(objNotificationMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstNotificationMasterDAL;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
