﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace mymLibrary
{
    public class mymFCMPushNotificationDAL
    {
        public string SendNotification(string DeviceId, string Title, string text, string MemberName, string imageName, string notificationType, string Id)
        {
            try
            {
                String ServerApiKey = mymGlobalsDAL.apiKeyabMYM;
                String SenderId = mymGlobalsDAL.senderIdabMYM;
                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", ServerApiKey));
                tRequest.Headers.Add(string.Format("Sender: id={0}", SenderId));
                tRequest.ContentType = "application/json";
                var data = new
                {
                    to = DeviceId,
                    data = new
                    {
                        body = text,
                        title = Title,
                        type = notificationType,
                        id = Id,
                        memberName = MemberName,
                        notificationImage = imageName,
                    },
                    content_available = true
                };

                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(data);
                Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                tRequest.ContentLength = byteArray.Length;

                using (Stream dataStream = tRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                    using (WebResponse tResponse = tRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = tResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();
                                return sResponseFromServer;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return ex.ToString();
            }
        }
    }
}
