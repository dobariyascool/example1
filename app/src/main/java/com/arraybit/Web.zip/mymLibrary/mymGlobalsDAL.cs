﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Web;
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;
using System.Data;
using System.Reflection;
using System.Data.SqlClient;

namespace mymLibrary
{
    public class mymGlobalsDAL
    {
        public const string UniqueKey = "yyyy-MM-dd_HH.mm.ss.ffff";
        public const string AuthenticationKey = "dsLh4MIqFHW5tjzSLD6JNJcL7ArwlhH/KqyTqeZEHi7MA/H8gWfNyrm7LxC9mBItJ4krl3PIF3Bl9yHsSfsecrofBNZyUoCth1bvReVO91hL3TggVVBHjft7tHVp+OtW";
        //public const string AuthenticationKey = "2ibAQWn/jPF4PM+0nVuWfhLeLP9CVXQhbsPTPCY8baB4NXhvg2pViq7S7SX0BtElGKK4hpunqoO2QSgrKupG8A==";
        public const string EncryptionKey = "31BF3856AD364E35";
        //Date Format
        public static string DateFormat = "MM'/'dd'/'yyyy";
        public static string TimeFormat = "HH:mm tt";
        public static string apiKeyabMYM = "AAAAAub1zPQ:APA91bEjsumRyiso_FRW3nbkIRFy30dLU4QknarsYq9Qm3PtwX3nlmCCNk_Q816mvD0PAIaGbGFZ9-w1Svsly7-2GQ9XE0AXTZDTN7FKYRdBogN-HgTXa12D45oKabN0X7nibzugzToF";
        public static string senderIdabMYM = "12464803060";
        public static DateTime FromDate;
        public static DateTime ToDate;

        public static void SaveError(Exception ex)
        {
            System.Threading.ThreadAbortException tae = ex as System.Threading.ThreadAbortException;
            if (tae != null)
            {
                return;
            }
            try
            {
                /// Insert error into ErrorLog table
                mymErrorLogDAL _objErrorLogDAL = new mymErrorLogDAL();
                _objErrorLogDAL.ErrorDateTime = mymGlobalsDAL.GetCurrentDateTime();
                _objErrorLogDAL.ErrorMessage = ex.Message;
                _objErrorLogDAL.ErrorStackTrace = ex.StackTrace;

                if (_objErrorLogDAL.InsertErrorLog() == mymRecordStatus.Error)
                {
                    /// Write error into ErrorLog file if error not inserted
                    string _strErrorLogFile = System.Configuration.ConfigurationManager.AppSettings["rootpath"] + System.Configuration.ConfigurationManager.AppSettings["ErrorFilePath"];
                    StringBuilder _sb = new StringBuilder();
                    _sb.AppendLine("Error DateTime    : " + mymGlobalsDAL.GetCurrentDateTime().ToString("s"));
                    _sb.AppendLine("Error Message     : " + ex.Message);
                    _sb.AppendLine("Error StackTrace  : " + ex.StackTrace);
                    _sb.AppendLine(string.Empty.PadRight(100, '-'));
                    File.WriteAllText(_strErrorLogFile, _sb.ToString());
                }
            }
            catch
            {
            }
        }

        public static string GetCleanFileName(string fileName)
        {
            string FileName = Regex.Replace(fileName, "[^a-zA-Z0-9_.]", "_");
            FileName = Path.GetFileNameWithoutExtension(FileName) + "_" + GetRandomString(6) + Path.GetExtension(FileName);
            return FileName;
        }

        public static string GetRandomString(int length)
        {
            //It will generate string with combination of small,capital letters and numbers
            char[] charArr = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToCharArray();
            string randomString = string.Empty;
            Random objRandom = new Random();
            for (int i = 0; i < length; i++)
            {
                //Don't Allow Repetation of Characters
                int x = objRandom.Next(1, charArr.Length);
                if (!randomString.Contains(charArr.GetValue(x).ToString()))
                {
                    randomString += charArr.GetValue(x);
                }
                else
                {
                    i--;
                }
            }
            return randomString;
        }

        public static DateTime GetCurrentDateTime()
        {
            TimeZoneInfo tzIndia = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.Now.ToUniversalTime(), tzIndia);
        }

        public static DataTable ToDataTable<T>(List<T> items, List<string> ExtraCollumns)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            foreach (string extraCollumn in ExtraCollumns)
            {
                dataTable.Columns.Remove(extraCollumn);
            }

            //put a breakpoint here and check datatable
            return dataTable;
        }

        public static string DecodeString(string url)
        {
            string Url = System.Web.HttpUtility.UrlDecode(url);
            Url = Url.Replace("~PERCENT~", "%").Replace("~CARET~", "^").Replace("~SPACE~", " ").Replace("~AMPERSAND~", "&").Replace("~ASTERISK~", "*").Replace("~COLON~", ":").Replace("~LESSTHAN~", "<").Replace("~COMMA~", ",").Replace("~GREATERTHAN~", ">").Replace("~DOT~", ".").Replace("~QUESTION~", "?").Replace("~BACKSLASH~", "\\").Replace("~PLUS~", "+");
            return Url;
        }

        #region Email
        public static void SendEmail(string ToEmail, string sub, string msg)
        {
            SendEmail(ToEmail, sub, msg, null);
        }

        public static void SendEmail(string ToEmail, string sub, string msg, string attachmentFileName)
        {
            //try
            //{
            //    if (!string.IsNullOrEmpty(ToEmail))
            //    {

            //        abHelper.Mail sendmail = new abHelper.Mail(System.Configuration.ConfigurationManager.AppSettings["abLibAuthKey"]);
            //        sendmail.Subject = sub;
            //        sendmail.ToMailAddresses = ToEmail;
            //        sendmail.FromMailAddress = System.Configuration.ConfigurationManager.AppSettings["FromMailAddress"];

            //        if (!string.IsNullOrEmpty(attachmentFileName))
            //        {
            //            sendmail.AttachmentFilesWithPath = attachmentFileName;
            //        }

            //        sendmail.Host = System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"];
            //        sendmail.Port = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]);
            //        sendmail.IsSSL = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["EmailIsSSL"]);
            //        sendmail.IsBodyHTML = true;
            //        sendmail.Body = msg;
            //        sendmail.Send();
            //    }
            //}
            //catch
            //{
            //}
        }
        #endregion

        #region SMS
        public static void SendSMS(string senderMobile, string msg, string receiverMobile)
        {
            try
            {
                //string user = System.Configuration.ConfigurationManager.AppSettings["MobileUser"];
                //string pwd = System.Configuration.ConfigurationManager.AppSettings["MobilePassword"];
                ////string myrecipient = "9426823910";
                ////msg = "You having a new booking, please check your V-GETIT bookings.";
                //HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create("http://smsidea.co.in/sendsms.aspx?mobile=" + user + "&pass=" + pwd + "&senderid=SMSWEB&to=" + senderMobile + "&msg=" + msg);

                //HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
                //System.IO.StreamReader respStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                //string responseString = respStreamReader.ReadToEnd();
                //respStreamReader.Close();
                //myResp.Close();
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
            }
        }

        #endregion
    }

    #region Record Status
    public enum mymRecordStatus
    {
        RecordNotFound = -3,
        RecordAlreadyExist = -2,
        Error = -1,
        Success = 0
    }
    #endregion

    #region Enum
    public enum mymMessageIcon
    {
        None,
        Success,
        Error,
        Information,
        Warning
    }

    public enum mymCustomerType
    {
        Customer = 1,
        Registered_User = 2,
        Creditor = 3
    }

    public enum mymAddressType
    {
        Home = 1,
        Office = 2
    }

    public enum mymBannerType
    {
        Item = 1,
        Offer = 2,
        Category = 3,
        General = 4
    }

    #endregion

    #region poswErrorStatus

    public class ErrorStatus
    {
        public int ErrorCode { get; set; }
        public long ErrorNumber { get; set; }
        public string ErrorMsg { get; set; }

        public ErrorStatus()
        {
            this.ErrorMsg = string.Empty;
        }
    }

    #endregion
}
