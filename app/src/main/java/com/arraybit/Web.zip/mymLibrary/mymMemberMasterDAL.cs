using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.IO;

namespace mymLibrary
{
    /// <summary>
    /// Class for mymMemberMaster
    /// </summary>
    public class mymMemberMasterDAL
    {
        #region Properties
        public int MemberMasterId { get; set; }
        public string MemberName { get; set; }
        public string ImageName { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string MemberType { get; set; }
        public DateTime LastLoginDateTime { get; set; }
        public string Gender { get; set; }
        public string Qualification { get; set; }
        public string BloodGroup { get; set; }
        public string Profession { get; set; }
        public DateTime? BirthDate { get; set; }
        public DateTime? AnniversaryDate { get; set; }
        public string HomeCountry { get; set; }
        public string HomeState { get; set; }
        public string HomeCity { get; set; }
        public string HomeArea { get; set; }
        public string HomeNumberStreet { get; set; }
        public string HomeNearBy { get; set; }
        public string HomeZipCode { get; set; }
        public string HomePhone { get; set; }
        public string OfficeCountry { get; set; }
        public string OfficeState { get; set; }
        public string OfficeCity { get; set; }
        public string OfficeArea { get; set; }
        public string OfficeNumberStreet { get; set; }
        public string OfficeNearBy { get; set; }
        public string OfficeZipCode { get; set; }
        public string OfficePhone { get; set; }
        public bool? IsApproved { get; set; }
        public bool IsAdminNotificationSent { get; set; }
        public bool IsMemberNotificationSent { get; set; }
        public string FCMToken { get; set; }
        public int? linktoMemberMasterIdApprovedBy { get; set; }
        public DateTime? ApprovedDateTime { get; set; }
        public int? linktoMemberMasterIdUpdatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public bool IsDeleted { get; set; }

        //Extra
        public List<mymMemberRelativesTranDAL> lstMemberRelativeTranDAL { get; set; }
        public string errorCode { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Member/";
            if (sqlRdr.Read())
            {
                this.MemberMasterId = Convert.ToInt32(sqlRdr["MemberMasterId"]);
                this.MemberName = Convert.ToString(sqlRdr["MemberName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);
                }
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                this.Email = Convert.ToString(sqlRdr["Email"]);
                this.Password = Convert.ToString(sqlRdr["Password"]);
                this.MemberType = Convert.ToString(sqlRdr["MemberType"]);
                this.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                this.Gender = Convert.ToString(sqlRdr["Gender"]);
                this.Qualification = Convert.ToString(sqlRdr["Qualification"]);
                this.BloodGroup = Convert.ToString(sqlRdr["BloodGroup"]);
                this.Profession = Convert.ToString(sqlRdr["Profession"]);
                if (sqlRdr["BirthDate"] != DBNull.Value)
                {
                    this.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                }
                if (sqlRdr["AnniversaryDate"] != DBNull.Value)
                {
                    this.AnniversaryDate = Convert.ToDateTime(sqlRdr["AnniversaryDate"]);
                }
                this.HomeCountry = Convert.ToString(sqlRdr["HomeCountry"]);
                this.HomeState = Convert.ToString(sqlRdr["HomeState"]);
                this.HomeCity = Convert.ToString(sqlRdr["HomeCity"]);
                this.HomeArea = Convert.ToString(sqlRdr["HomeArea"]);
                this.HomeNumberStreet = Convert.ToString(sqlRdr["HomeNumberStreet"]);
                this.HomeNearBy = Convert.ToString(sqlRdr["HomeNearBy"]);
                this.HomeZipCode = Convert.ToString(sqlRdr["HomeZipCode"]);
                this.HomePhone = Convert.ToString(sqlRdr["HomePhone"]);
                this.OfficeCountry = Convert.ToString(sqlRdr["OfficeCountry"]);
                this.OfficeState = Convert.ToString(sqlRdr["OfficeState"]);
                this.OfficeCity = Convert.ToString(sqlRdr["OfficeCity"]);
                this.OfficeArea = Convert.ToString(sqlRdr["OfficeArea"]);
                this.OfficeNumberStreet = Convert.ToString(sqlRdr["OfficeNumberStreet"]);
                this.OfficeNearBy = Convert.ToString(sqlRdr["OfficeNearBy"]);
                this.OfficeZipCode = Convert.ToString(sqlRdr["OfficeZipCode"]);
                this.OfficePhone = Convert.ToString(sqlRdr["OfficePhone"]);
                if (sqlRdr["IsApproved"] != DBNull.Value)
                {
                    this.IsApproved = Convert.ToBoolean(sqlRdr["IsApproved"]);
                }
                this.IsAdminNotificationSent = Convert.ToBoolean(sqlRdr["IsAdminNotificationSent"]);
                this.IsMemberNotificationSent = Convert.ToBoolean(sqlRdr["IsMemberNotificationSent"]);
                this.FCMToken = Convert.ToString(sqlRdr["FCMToken"]);
                if (sqlRdr["linktoMemberMasterIdApprovedBy"] != DBNull.Value)
                {
                    this.linktoMemberMasterIdApprovedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdApprovedBy"]);
                }
                if (sqlRdr["ApprovedDateTime"] != DBNull.Value)
                {
                    this.ApprovedDateTime = Convert.ToDateTime(sqlRdr["ApprovedDateTime"]);
                }
                if (sqlRdr["linktoMemberMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                return true;
            }
            return false;
        }

        private List<mymMemberMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Member/";
            List<mymMemberMasterDAL> lstMemberMaster = new List<mymMemberMasterDAL>();
            mymMemberMasterDAL objMemberMaster = null;
            while (sqlRdr.Read())
            {
                objMemberMaster = new mymMemberMasterDAL();
                objMemberMaster.MemberMasterId = Convert.ToInt32(sqlRdr["MemberMasterId"]);
                objMemberMaster.MemberName = Convert.ToString(sqlRdr["MemberName"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objMemberMaster.ImageName = ImageRetrievePath + Convert.ToString(sqlRdr["ImageName"]);
                }
                objMemberMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objMemberMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                objMemberMaster.Email = Convert.ToString(sqlRdr["Email"]);
                objMemberMaster.Password = Convert.ToString(sqlRdr["Password"]);
                objMemberMaster.MemberType = Convert.ToString(sqlRdr["MemberType"]);
                objMemberMaster.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                objMemberMaster.Gender = Convert.ToString(sqlRdr["Gender"]);
                objMemberMaster.Qualification = Convert.ToString(sqlRdr["Qualification"]);
                objMemberMaster.BloodGroup = Convert.ToString(sqlRdr["BloodGroup"]);
                objMemberMaster.Profession = Convert.ToString(sqlRdr["Profession"]);
                if (sqlRdr["BirthDate"] != DBNull.Value)
                {
                    objMemberMaster.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                }
                if (sqlRdr["AnniversaryDate"] != DBNull.Value)
                {
                    objMemberMaster.AnniversaryDate = Convert.ToDateTime(sqlRdr["AnniversaryDate"]);
                }
                objMemberMaster.HomeCountry = Convert.ToString(sqlRdr["HomeCountry"]);
                objMemberMaster.HomeState = Convert.ToString(sqlRdr["HomeState"]);
                objMemberMaster.HomeCity = Convert.ToString(sqlRdr["HomeCity"]);
                objMemberMaster.HomeArea = Convert.ToString(sqlRdr["HomeArea"]);
                objMemberMaster.HomeNumberStreet = Convert.ToString(sqlRdr["HomeNumberStreet"]);
                objMemberMaster.HomeNearBy = Convert.ToString(sqlRdr["HomeNearBy"]);
                objMemberMaster.HomeZipCode = Convert.ToString(sqlRdr["HomeZipCode"]);
                objMemberMaster.HomePhone = Convert.ToString(sqlRdr["HomePhone"]);
                objMemberMaster.HomeZipCode = Convert.ToString(sqlRdr["HomeZipCode"]);
                objMemberMaster.OfficeCountry = Convert.ToString(sqlRdr["OfficeCountry"]);
                objMemberMaster.OfficeState = Convert.ToString(sqlRdr["OfficeState"]);
                objMemberMaster.OfficeCity = Convert.ToString(sqlRdr["OfficeCity"]);
                objMemberMaster.OfficeArea = Convert.ToString(sqlRdr["OfficeArea"]);
                objMemberMaster.OfficeNumberStreet = Convert.ToString(sqlRdr["OfficeNumberStreet"]);
                objMemberMaster.OfficeNearBy = Convert.ToString(sqlRdr["OfficeNearBy"]);
                objMemberMaster.OfficeZipCode = Convert.ToString(sqlRdr["OfficeZipCode"]);
                objMemberMaster.OfficePhone = Convert.ToString(sqlRdr["OfficePhone"]);
                if (sqlRdr["IsApproved"] != DBNull.Value)
                {
                    objMemberMaster.IsApproved = Convert.ToBoolean(sqlRdr["IsApproved"]);
                }
                if (sqlRdr["FCMToken"] != DBNull.Value)
                {
                    objMemberMaster.FCMToken = Convert.ToString(sqlRdr["FCMToken"]);
                }
                if (sqlRdr["linktoMemberMasterIdApprovedBy"] != DBNull.Value)
                {
                    objMemberMaster.linktoMemberMasterIdApprovedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdApprovedBy"]);
                }
                if (sqlRdr["ApprovedDateTime"] != DBNull.Value)
                {
                    objMemberMaster.ApprovedDateTime = Convert.ToDateTime(sqlRdr["ApprovedDateTime"]);
                }
                if (sqlRdr["linktoMemberMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objMemberMaster.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objMemberMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                lstMemberMaster.Add(objMemberMaster);
            }
            return lstMemberMaster;
        }
        #endregion

        #region Insert

        public mymRecordStatus InsertMemberMasterDetail()   
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("mymMemberMasterDetail_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@MemberName", SqlDbType.VarChar).Value = this.MemberName;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@MemberType", SqlDbType.VarChar).Value = this.MemberType;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@FCMToken", SqlDbType.VarChar).Value = this.FCMToken;

                //Personal Detail
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@Qualification", SqlDbType.VarChar).Value = this.Qualification;
                SqlCmd.Parameters.Add("@BloodGroup", SqlDbType.VarChar).Value = this.BloodGroup;
                SqlCmd.Parameters.Add("@Profession", SqlDbType.VarChar).Value = this.Profession;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.Date).Value = this.AnniversaryDate;

                //Contact Detail
                SqlCmd.Parameters.Add("@HomeCountry", SqlDbType.VarChar).Value = this.HomeCountry;
                SqlCmd.Parameters.Add("@HomeState", SqlDbType.VarChar).Value = this.HomeState;
                SqlCmd.Parameters.Add("@HomeCity", SqlDbType.VarChar).Value = this.HomeCity;
                SqlCmd.Parameters.Add("@HomeArea", SqlDbType.VarChar).Value = this.HomeArea;
                SqlCmd.Parameters.Add("@HomeNumberStreet", SqlDbType.VarChar).Value = this.HomeNumberStreet;
                SqlCmd.Parameters.Add("@HomeNearBy", SqlDbType.VarChar).Value = this.HomeNearBy;
                SqlCmd.Parameters.Add("@HomeZipCode", SqlDbType.VarChar).Value = this.HomeZipCode;
                SqlCmd.Parameters.Add("@HomePhone", SqlDbType.VarChar).Value = this.HomePhone;
                SqlCmd.Parameters.Add("@OfficeCountry", SqlDbType.VarChar).Value = this.OfficeCountry;
                SqlCmd.Parameters.Add("@OfficeState", SqlDbType.VarChar).Value = this.OfficeState;
                SqlCmd.Parameters.Add("@OfficeCity", SqlDbType.VarChar).Value = this.OfficeCity;
                SqlCmd.Parameters.Add("@OfficeArea", SqlDbType.VarChar).Value = this.OfficeArea;
                SqlCmd.Parameters.Add("@OfficeNumberStreet", SqlDbType.VarChar).Value = this.OfficeNumberStreet;
                SqlCmd.Parameters.Add("@OfficeNearBy", SqlDbType.VarChar).Value = this.OfficeNearBy;
                SqlCmd.Parameters.Add("@OfficeZipCode", SqlDbType.VarChar).Value = this.OfficeZipCode;
                SqlCmd.Parameters.Add("@OfficePhone", SqlDbType.VarChar).Value = this.OfficePhone;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.MemberMasterId = Convert.ToInt32(SqlCmd.Parameters["@MemberMasterId"].Value);
                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == mymRecordStatus.Success)
                {
                    if (this.AnniversaryDate != null)
                    {
                        if (this.lstMemberRelativeTranDAL != null && this.lstMemberRelativeTranDAL.Count > 0)
                        {
                            mymMemberRelativesTranDAL objMemberRelativeTran1DAL = new mymMemberRelativesTranDAL();
                            objMemberRelativeTran1DAL.linktoMemberMasterId = this.MemberMasterId;
                            mymRecordStatus rs1 = objMemberRelativeTran1DAL.DeleteAllMemberRelativesTran(SqlCon, SqlTran);
                            if (rs1 == mymRecordStatus.Error)
                            {
                                SqlTran.Rollback();
                                return rs1;
                            }

                            rs1 = mymRecordStatus.Error;
                            foreach (mymMemberRelativesTranDAL objMemberRelativeTranDAL in this.lstMemberRelativeTranDAL)
                            {
                                objMemberRelativeTranDAL.linktoMemberMasterId = this.MemberMasterId;
                                rs1 = objMemberRelativeTranDAL.InsertMemberRelativesTran(SqlCon, SqlTran);
                                if (rs1 == mymRecordStatus.Error)
                                {
                                    SqlTran.Rollback();
                                    return rs1;
                                }

                            }
                            if (rs1 == mymRecordStatus.Success)
                            {
                                SqlTran.Commit();
                                return rs1;
                            }
                            else
                            {
                                SqlTran.Rollback();
                                return rs1;
                            }
                        }
                        else
                        {
                            SqlTran.Commit();
                            return rs;
                        }
                    }
                    else
                    {
                        mymMemberRelativesTranDAL objMemberRelativeTranDAL = new mymMemberRelativesTranDAL();
                        objMemberRelativeTranDAL.linktoMemberMasterId = this.MemberMasterId;
                        mymRecordStatus rs1 = objMemberRelativeTranDAL.DeleteAllMemberRelativesTran(SqlCon, SqlTran);
                        if (rs1 == mymRecordStatus.Success)
                        {
                            SqlTran.Commit();
                            return rs1;
                        }
                        else
                        {
                            SqlTran.Rollback();
                            return rs1;
                        }
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return rs;
                }
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public mymRecordStatus UpdateMemberMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@MemberName", SqlDbType.VarChar).Value = this.MemberName;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@MemberType", SqlDbType.VarChar).Value = this.MemberType;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Qualification", SqlDbType.VarChar).Value = this.Qualification;
                SqlCmd.Parameters.Add("@BloodGroup", SqlDbType.VarChar).Value = this.BloodGroup;
                SqlCmd.Parameters.Add("@Profession", SqlDbType.VarChar).Value = this.Profession;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.Date).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@HomeCountry", SqlDbType.VarChar).Value = this.HomeCountry;
                SqlCmd.Parameters.Add("@HomeState", SqlDbType.VarChar).Value = this.HomeState;
                SqlCmd.Parameters.Add("@HomeCity", SqlDbType.VarChar).Value = this.HomeCity;
                SqlCmd.Parameters.Add("@HomeArea", SqlDbType.VarChar).Value = this.HomeArea;
                SqlCmd.Parameters.Add("@HomeNumberStreet", SqlDbType.VarChar).Value = this.HomeNumberStreet;
                SqlCmd.Parameters.Add("@HomeNearBy", SqlDbType.VarChar).Value = this.HomeNearBy;
                SqlCmd.Parameters.Add("@HomeZipCode", SqlDbType.VarChar).Value = this.HomeZipCode;
                SqlCmd.Parameters.Add("@HomePhone", SqlDbType.VarChar).Value = this.HomePhone;
                SqlCmd.Parameters.Add("@OfficeCountry", SqlDbType.VarChar).Value = this.OfficeCountry;
                SqlCmd.Parameters.Add("@OfficeState", SqlDbType.VarChar).Value = this.OfficeState;
                SqlCmd.Parameters.Add("@OfficeCity", SqlDbType.VarChar).Value = this.OfficeCity;
                SqlCmd.Parameters.Add("@OfficeArea", SqlDbType.VarChar).Value = this.OfficeArea;
                SqlCmd.Parameters.Add("@OfficeNumberStreet", SqlDbType.VarChar).Value = this.OfficeNumberStreet;
                SqlCmd.Parameters.Add("@OfficeNearBy", SqlDbType.VarChar).Value = this.OfficeNearBy;
                SqlCmd.Parameters.Add("@OfficeZipCode", SqlDbType.VarChar).Value = this.OfficeZipCode;
                SqlCmd.Parameters.Add("@OfficePhone", SqlDbType.VarChar).Value = this.OfficePhone;
                SqlCmd.Parameters.Add("@IsApproved", SqlDbType.Bit).Value = this.IsApproved;
                SqlCmd.Parameters.Add("@IsAdminNotificationSent", SqlDbType.Bit).Value = this.IsAdminNotificationSent;
                SqlCmd.Parameters.Add("@IsMemberNotificationSent", SqlDbType.Bit).Value = this.IsMemberNotificationSent;
                SqlCmd.Parameters.Add("@FCMToken", SqlDbType.VarChar).Value = this.FCMToken;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdApprovedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdApprovedBy;
                SqlCmd.Parameters.Add("@ApprovedDateTime", SqlDbType.DateTime).Value = this.ApprovedDateTime;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterPersonalDetail()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("mymMemberMasterPersonalDetail_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@Qualification", SqlDbType.VarChar).Value = this.Qualification;
                SqlCmd.Parameters.Add("@BloodGroup", SqlDbType.VarChar).Value = this.BloodGroup;
                SqlCmd.Parameters.Add("@Profession", SqlDbType.VarChar).Value = this.Profession;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.Date).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == mymRecordStatus.Success)
                {
                    if (this.AnniversaryDate != null)
                    {
                        if (this.lstMemberRelativeTranDAL != null && this.lstMemberRelativeTranDAL.Count > 0)
                        {
                            mymMemberRelativesTranDAL objMemberRelativeTran1DAL = new mymMemberRelativesTranDAL();
                            objMemberRelativeTran1DAL.linktoMemberMasterId = this.MemberMasterId;
                            mymRecordStatus rs1 = objMemberRelativeTran1DAL.DeleteAllMemberRelativesTran(SqlCon, SqlTran);
                            if (rs1 == mymRecordStatus.Error)
                            {
                                SqlTran.Rollback();
                                return rs1;
                            }

                            rs1 = mymRecordStatus.Error;
                            foreach (mymMemberRelativesTranDAL objMemberRelativeTranDAL in this.lstMemberRelativeTranDAL)
                            {
                                rs1 = objMemberRelativeTranDAL.InsertMemberRelativesTran(SqlCon, SqlTran);
                                if (rs1 == mymRecordStatus.Error)
                                {
                                    SqlTran.Rollback();
                                    return rs1;
                                }
                            }
                            if (rs1 == mymRecordStatus.Success)
                            {
                                SqlTran.Commit();
                                return rs1;
                            }
                            else
                            {
                                SqlTran.Rollback();
                                return rs1;
                            }
                        }
                        else
                        {
                            SqlTran.Commit();
                            return rs;
                        }
                    }
                    else
                    {
                        mymMemberRelativesTranDAL objMemberRelativeTranDAL = new mymMemberRelativesTranDAL();
                        objMemberRelativeTranDAL.linktoMemberMasterId = this.MemberMasterId;
                        mymRecordStatus rs1 = objMemberRelativeTranDAL.DeleteAllMemberRelativesTran(SqlCon, SqlTran);
                        if (rs1 == mymRecordStatus.Success)
                        {
                            SqlTran.Commit();
                            return rs1;
                        }
                        else
                        {
                            SqlTran.Rollback();
                            return rs1;
                        }
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return rs;
                }
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterContactDetail()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterContactDetail_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@HomeCountry", SqlDbType.VarChar).Value = this.HomeCountry;
                SqlCmd.Parameters.Add("@HomeState", SqlDbType.VarChar).Value = this.HomeState;
                SqlCmd.Parameters.Add("@HomeCity", SqlDbType.VarChar).Value = this.HomeCity;
                SqlCmd.Parameters.Add("@HomeArea", SqlDbType.VarChar).Value = this.HomeArea;
                SqlCmd.Parameters.Add("@HomeNumberStreet", SqlDbType.VarChar).Value = this.HomeNumberStreet;
                SqlCmd.Parameters.Add("@HomeNearBy", SqlDbType.VarChar).Value = this.HomeNearBy;
                SqlCmd.Parameters.Add("@HomeZipCode", SqlDbType.VarChar).Value = this.HomeZipCode;
                SqlCmd.Parameters.Add("@HomePhone", SqlDbType.VarChar).Value = this.HomePhone;
                SqlCmd.Parameters.Add("@OfficeCountry", SqlDbType.VarChar).Value = this.OfficeCountry;
                SqlCmd.Parameters.Add("@OfficeState", SqlDbType.VarChar).Value = this.OfficeState;
                SqlCmd.Parameters.Add("@OfficeCity", SqlDbType.VarChar).Value = this.OfficeCity;
                SqlCmd.Parameters.Add("@OfficeArea", SqlDbType.VarChar).Value = this.OfficeArea;
                SqlCmd.Parameters.Add("@OfficeNumberStreet", SqlDbType.VarChar).Value = this.OfficeNumberStreet;
                SqlCmd.Parameters.Add("@OfficeNearBy", SqlDbType.VarChar).Value = this.OfficeNearBy;
                SqlCmd.Parameters.Add("@OfficeZipCode", SqlDbType.VarChar).Value = this.OfficeZipCode;
                SqlCmd.Parameters.Add("@OfficePhone", SqlDbType.VarChar).Value = this.OfficePhone;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterByMemberMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterByMemebermasterId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@MemberName", SqlDbType.VarChar).Value = this.MemberName;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public String UpdateMemberMasterImageByMemberMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Member/";
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterImageByMemebermasterId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == mymRecordStatus.Success)
                {
                    if (this.ImageName != null)
                    {
                        return ImageRetrievePath + this.ImageName;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterIsApproved()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterIsApproved_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@IsApproved", SqlDbType.Bit).Value = this.IsApproved;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdApprovedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdApprovedBy;
                SqlCmd.Parameters.Add("@ApprovedDateTime", SqlDbType.DateTime).Value = this.ApprovedDateTime;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus DeleteMemberMasterByMemberMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterByMemberMasterId_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterAdmin()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterAdmin_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@MemberType", SqlDbType.VarChar).Value = this.MemberType;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterPassword(string confirmPassword)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterPassword_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@ConfirmPassword", SqlDbType.VarChar).Value = confirmPassword;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterLogOut()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterLogout_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@FCMToken", SqlDbType.VarChar).Value = this.FCMToken;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateUserMasterLastLoginDateTime()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterLastLoginDateTime_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.SmallInt).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateMemberMasterFCMToken()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterFCMToken_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.VarChar).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@FCMToken", SqlDbType.VarChar).Value = this.FCMToken;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete

        #endregion

        #region Select
        public bool SelectMemberByMemberMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterByMembermasterId_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.Int).Value = this.MemberMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                if (IsSelected && this.AnniversaryDate != null)
                {
                    mymMemberRelativesTranDAL objMemberRelativesTranDAL = new mymMemberRelativesTranDAL();
                    objMemberRelativesTranDAL.linktoMemberMasterId = this.MemberMasterId;
                    lstMemberRelativeTranDAL = objMemberRelativesTranDAL.SelectAllMemberRelativesTranbyMemberMasterId();
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectMemberMasterByEmail()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterByEmail_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<mymMemberMasterDAL> SelectAllMemberMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.SmallInt).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<mymMemberMasterDAL> lstMemberMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstMemberMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<mymMemberMasterDAL> SelectAllMemberMasterFilterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterFilterPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MemberMasterId", SqlDbType.SmallInt).Value = this.MemberMasterId;
                SqlCmd.Parameters.Add("@MemberName", SqlDbType.VarChar).Value = this.MemberName;
                SqlCmd.Parameters.Add("@Profession", SqlDbType.VarChar).Value = this.Profession;
                SqlCmd.Parameters.Add("@Qualification", SqlDbType.VarChar).Value = this.Qualification;
                SqlCmd.Parameters.Add("@BloodGroup", SqlDbType.VarChar).Value = this.BloodGroup;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<mymMemberMasterDAL> lstMemberMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstMemberMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<mymMemberMasterDAL> SelectAllNewMemberMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterNewPageWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
                SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
                SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<mymMemberMasterDAL> lstMemberMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
                return lstMemberMasterDAL;
            }
            catch (Exception ex)
            {
                totalRecords = 0;
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<mymMemberMasterDAL> SelectAllMemberMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<mymMemberMasterDAL> lstMemberMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMemberMasterDAL;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<String> SelectAllProfession()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterProfession_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<String> lstString = new List<String>();
                while (SqlRdr.Read())
                {
                    if (SqlRdr["Profession"] != DBNull.Value)
                    {
                        lstString.Add(Convert.ToString(SqlRdr["Profession"]));
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstString;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<String> SelectAllQualification()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterQualification_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<String> lstString = new List<String>();
                string Qualification;
                while (SqlRdr.Read())
                {
                    if (SqlRdr["Qualification"] != DBNull.Value)
                    {
                        Qualification = Convert.ToString(SqlRdr["Qualification"]);
                        if (Qualification.IndexOf(',') != -1)
                        {
                            string[] stringlist = Qualification.Split(',');
                            for (int i = 0; i < stringlist.Length; i++)
                            {
                                stringlist[i] = stringlist[i].TrimStart();
                            }
                            lstString.AddRange(stringlist);
                        }
                        else
                        {
                            lstString.Add(Qualification);
                        }
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstString;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        public mymRecordStatus ForgotPasswordMemberMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymMemberMasterByEmail_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();
                if (IsSelected)
                {
                    try
                    {
                        abHelper.Mail objMail = new abHelper.Mail(System.Configuration.ConfigurationManager.AppSettings["abLibAuthKey"]);
                        objMail.FromMailAddress = System.Configuration.ConfigurationManager.AppSettings["FromMailAddress"];
                        objMail.ToMailAddresses = this.Email;
                        objMail.Subject = "Login details for your SMYM account";

                        string body = "Hello " + this.MemberName + ",<br>" +
                            "<br>" +
                            "Here are your login details for your SMYM account." +
                            "<br><br>" +
                            "Email: " + this.Email + "<br>" +
                            "Password:  " + this.Password + "<br>" +
                            "<br>" +
                            "To change your password, log in with the above details,<br>" +
                            "Go to 'My Account' and then click 'Change Password'.<br>" +
                            "<br>" +
                            "<br>" +
                            "Thanks & Regards,<br>" +
                            "Shree Mahavir Yuvak Mandal";

                        objMail.Body = body;

                        objMail.Host = System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"];
                        objMail.Port = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]);
                        objMail.IsSSL = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["EmailIsSSL"]);
                        objMail.IsBodyHTML = true;
                        objMail.Send();

                        return mymRecordStatus.Success;
                    }
                    catch (Exception ex)
                    {
                        mymGlobalsDAL.SaveError(ex);
                        return mymRecordStatus.Error;
                    }
                }
                else
                {
                    return mymRecordStatus.RecordAlreadyExist;
                }
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
    }
}
