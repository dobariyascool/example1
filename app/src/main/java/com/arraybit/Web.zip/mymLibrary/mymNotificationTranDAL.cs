using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Class for mymNotificationTran
	/// </summary>
	public class mymNotificationTranDAL
	{
		#region Properties
		public long NotificationTranId { get; set; }
		public int linktoNotificationMasterId { get; set; }
		public int linktoMemberMasterId { get; set; }
		public DateTime ReadDateTime { get; set; }

		/// Extra
		public int Notification { get; set; }
		public int Member { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.NotificationTranId = Convert.ToInt64(sqlRdr["NotificationTranId"]);
				this.linktoNotificationMasterId = Convert.ToInt32(sqlRdr["linktoNotificationMasterId"]);
				this.linktoMemberMasterId = Convert.ToInt32(sqlRdr["linktoMemberMasterId"]);
				this.ReadDateTime = Convert.ToDateTime(sqlRdr["ReadDateTime"]);

				/// Extra
				this.Notification = Convert.ToInt32(sqlRdr["Notification"]);
				this.Member = Convert.ToInt32(sqlRdr["Member"]);
				return true;
			}
			return false;
		}

		private List<mymNotificationTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<mymNotificationTranDAL> lstNotificationTran = new List<mymNotificationTranDAL>();
			mymNotificationTranDAL objNotificationTran = null;
			while (sqlRdr.Read())
			{
				objNotificationTran = new mymNotificationTranDAL();
				objNotificationTran.NotificationTranId = Convert.ToInt64(sqlRdr["NotificationTranId"]);
				objNotificationTran.linktoNotificationMasterId = Convert.ToInt32(sqlRdr["linktoNotificationMasterId"]);
				objNotificationTran.linktoMemberMasterId = Convert.ToInt32(sqlRdr["linktoMemberMasterId"]);
				objNotificationTran.ReadDateTime = Convert.ToDateTime(sqlRdr["ReadDateTime"]);

				/// Extra
				objNotificationTran.Notification = Convert.ToInt32(sqlRdr["Notification"]);
				objNotificationTran.Member = Convert.ToInt32(sqlRdr["Member"]);
				lstNotificationTran.Add(objNotificationTran);
			}
			return lstNotificationTran;
		}
		#endregion

		#region Insert
		public mymRecordStatus InsertNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoNotificationMasterId", SqlDbType.Int).Value = this.linktoNotificationMasterId;
				SqlCmd.Parameters.Add("@linktoMemberMasterId", SqlDbType.Int).Value = this.linktoMemberMasterId;
				SqlCmd.Parameters.Add("@ReadDateTime", SqlDbType.DateTime).Value = this.ReadDateTime;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.NotificationTranId = Convert.ToInt64(SqlCmd.Parameters["@NotificationTranId"].Value);
				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public mymRecordStatus UpdateNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationTran_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationTranId", SqlDbType.BigInt).Value = this.NotificationTranId;
				SqlCmd.Parameters.Add("@linktoNotificationMasterId", SqlDbType.Int).Value = this.linktoNotificationMasterId;
				SqlCmd.Parameters.Add("@linktoMemberMasterId", SqlDbType.Int).Value = this.linktoMemberMasterId;
				SqlCmd.Parameters.Add("@ReadDateTime", SqlDbType.DateTime).Value = this.ReadDateTime;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public mymRecordStatus DeleteNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationTran_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationTranId", SqlDbType.BigInt).Value = this.NotificationTranId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationTran_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@NotificationTranId", SqlDbType.BigInt).Value = this.NotificationTranId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<mymNotificationTranDAL> SelectAllNotificationTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<mymNotificationTranDAL> lstNotificationTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstNotificationTranDAL;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<mymNotificationTranDAL> SelectAllNotificationTranNotificationTranId()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymNotificationTranNotificationTranId_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<mymNotificationTranDAL> lstNotificationTranDAL = new List<mymNotificationTranDAL>();
				mymNotificationTranDAL objNotificationTranDAL = null;
				while (SqlRdr.Read())
				{
					objNotificationTranDAL = new mymNotificationTranDAL();
					objNotificationTranDAL.NotificationTranId = Convert.ToInt64(SqlRdr["NotificationTranId"]);
					lstNotificationTranDAL.Add(objNotificationTranDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstNotificationTranDAL;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
