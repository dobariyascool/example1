using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Class for mymAdvertiseMaster
	/// </summary>
	public class mymAdvertiseMasterDAL
	{
		#region Properties
		public int AdvertiseMasterId { get; set; }
		public string AdvertiseText { get; set; }
		public string AdvertiseImageName { get; set; }
		public string WebsiteURL { get; set; }
		public string AdvertisementType { get; set; }
		public int linktoMemberMasterIdCreatedBy { get; set; }
		public DateTime CreateDateTime { get; set; }
		public int? linktoMemberMasterIdUpdatedBy { get; set; }
		public DateTime? UpdateDateTime { get; set; }
		public bool IsEnabled { get; set; }
		public bool IsDeleted { get; set; }

		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Advertise/";
			if (sqlRdr.Read())
			{
				this.AdvertiseMasterId = Convert.ToInt32(sqlRdr["AdvertiseMasterId"]);
				this.AdvertiseText = Convert.ToString(sqlRdr["AdvertiseText"]);
                if (sqlRdr["AdvertiseImageName"] != DBNull.Value)
                {
                    this.AdvertiseImageName = ImageRetrievePath + Convert.ToString(sqlRdr["AdvertiseImageName"]);
                }
				this.WebsiteURL = Convert.ToString(sqlRdr["WebsiteURL"]);
				this.AdvertisementType = Convert.ToString(sqlRdr["AdvertisementType"]);
				this.linktoMemberMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdCreatedBy"]);
				this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				if (sqlRdr["linktoMemberMasterIdUpdatedBy"] != DBNull.Value)
				{
					this.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdUpdatedBy"]);
				}
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
		
				return true;
			}
			return false;
		}

		private List<mymAdvertiseMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Advertise/";
			List<mymAdvertiseMasterDAL> lstAdvertiseMaster = new List<mymAdvertiseMasterDAL>();
			mymAdvertiseMasterDAL objAdvertiseMaster = null;
			while (sqlRdr.Read())
			{
				objAdvertiseMaster = new mymAdvertiseMasterDAL();
				objAdvertiseMaster.AdvertiseMasterId = Convert.ToInt32(sqlRdr["AdvertiseMasterId"]);
				objAdvertiseMaster.AdvertiseText = Convert.ToString(sqlRdr["AdvertiseText"]);
                if (sqlRdr["AdvertiseImageName"] != DBNull.Value)
                {
                    objAdvertiseMaster.AdvertiseImageName = ImageRetrievePath + Convert.ToString(sqlRdr["AdvertiseImageName"]);
                }
				objAdvertiseMaster.WebsiteURL = Convert.ToString(sqlRdr["WebsiteURL"]);
				objAdvertiseMaster.AdvertisementType = Convert.ToString(sqlRdr["AdvertisementType"]);
				objAdvertiseMaster.linktoMemberMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdCreatedBy"]);
				objAdvertiseMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				if (sqlRdr["linktoMemberMasterIdUpdatedBy"] != DBNull.Value)
				{
					objAdvertiseMaster.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoMemberMasterIdUpdatedBy"]);
				}
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					objAdvertiseMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				objAdvertiseMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				objAdvertiseMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

				lstAdvertiseMaster.Add(objAdvertiseMaster);
			}
			return lstAdvertiseMaster;
		}
		#endregion

		#region Insert
		public mymRecordStatus InsertAdvertiseMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymAdvertiseMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@AdvertiseMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@AdvertiseText", SqlDbType.VarChar).Value = this.AdvertiseText;
				SqlCmd.Parameters.Add("@AdvertiseImageName", SqlDbType.VarChar).Value = this.AdvertiseImageName;
				SqlCmd.Parameters.Add("@WebsiteURL", SqlDbType.VarChar).Value = this.WebsiteURL;
				SqlCmd.Parameters.Add("@AdvertisementType", SqlDbType.VarChar).Value = this.AdvertisementType;
				SqlCmd.Parameters.Add("@linktoMemberMasterIdCreatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.AdvertiseMasterId = Convert.ToInt32(SqlCmd.Parameters["@AdvertiseMasterId"].Value);
				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public mymRecordStatus UpdateAdvertiseMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymAdvertiseMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@AdvertiseMasterId", SqlDbType.Int).Value = this.AdvertiseMasterId;
				SqlCmd.Parameters.Add("@AdvertiseText", SqlDbType.VarChar).Value = this.AdvertiseText;
				SqlCmd.Parameters.Add("@AdvertiseImageName", SqlDbType.VarChar).Value = this.AdvertiseImageName;
				SqlCmd.Parameters.Add("@WebsiteURL", SqlDbType.VarChar).Value = this.WebsiteURL;
				SqlCmd.Parameters.Add("@AdvertisementType", SqlDbType.VarChar).Value = this.AdvertisementType;
				SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;	
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public mymRecordStatus UpdateAdvertiseMasterDisable()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymAdvertiseMasterDisableByAdvertiseMasterId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AdvertiseMasterId", SqlDbType.Int).Value = this.AdvertiseMasterId;              
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;               
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public mymRecordStatus UpdateAdvertiseMasterDelete()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = mymObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("mymAdvertiseMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AdvertiseMasterId", SqlDbType.Int).Value = this.AdvertiseMasterId;
                SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return mymRecordStatus.Error;
            }
            finally
            {
                mymObjectFactoryDAL.DisposeCommand(SqlCmd);
                mymObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

		#endregion

		#region Delete
		public mymRecordStatus DeleteAdvertiseMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymAdvertiseMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@AdvertiseMasterId", SqlDbType.Int).Value = this.AdvertiseMasterId;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@linktoMemberMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoMemberMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				mymRecordStatus rs = (mymRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return mymRecordStatus.Error;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectAdvertiseMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymAdvertiseMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@AdvertiseMasterId", SqlDbType.Int).Value = this.AdvertiseMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<mymAdvertiseMasterDAL> SelectAllAdvertiseMasterPageWise(short startRowIndex, short pageSize, out short totalRecords)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymAdvertiseMasterPageWise_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;
                if (pageSize == 1)
                {
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                }
                else
                {
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = null;
                }

				SqlCmd.Parameters.Add("@StartRowIndex", SqlDbType.SmallInt).Value = startRowIndex;
				SqlCmd.Parameters.Add("@PageSize", SqlDbType.SmallInt).Value = pageSize;
				SqlCmd.Parameters.Add("@TotalRowCount", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<mymAdvertiseMasterDAL> lstAdvertiseMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				totalRecords = (short)SqlCmd.Parameters["@TotalRowCount"].Value;
				return lstAdvertiseMasterDAL;
			}
			catch (Exception ex)
			{
				totalRecords = 0;
				mymGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<mymAdvertiseMasterDAL> SelectAllAdvertiseMasterAdvertiseMasterId()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = mymObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("mymAdvertiseMasterAdvertiseMasterId_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<mymAdvertiseMasterDAL> lstAdvertiseMasterDAL = new List<mymAdvertiseMasterDAL>();
				mymAdvertiseMasterDAL objAdvertiseMasterDAL = null;
				while (SqlRdr.Read())
				{
					objAdvertiseMasterDAL = new mymAdvertiseMasterDAL();
					objAdvertiseMasterDAL.AdvertiseMasterId = Convert.ToInt32(SqlRdr["AdvertiseMasterId"]);
					lstAdvertiseMasterDAL.Add(objAdvertiseMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstAdvertiseMasterDAL;
			}
			catch (Exception ex)
			{
				mymGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				mymObjectFactoryDAL.DisposeDataReader(SqlRdr);
				mymObjectFactoryDAL.DisposeCommand(SqlCmd);
				mymObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
