﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using mymLibrary;
using System.ServiceModel.Web;
using System.Text;
using System.IO;
using System.Drawing;

namespace mymService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class Service1 : IService
    {
        #region Insert

        public MemberMaster InsertMemberMasterDetail(MemberMaster memberMaster)
        {
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "Member\\";
            string ImageSavePathRelative = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "MemberRelative\\";

            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberName = memberMaster.MemberName;
                if (memberMaster.ImageNameBytes != null)
                {
                    if (!Directory.Exists(ImageSavePath))
                    {
                        Directory.CreateDirectory(ImageSavePath);
                    }
                    byte[] buffer = Convert.FromBase64String(memberMaster.ImageNameBytes);
                    MemoryStream ms = new MemoryStream(buffer);
                    Image image = Image.FromStream(ms);
                    image.Save(ImageSavePath + memberMaster.ImageName);
                    objMemberMasterDAL.ImageName = memberMaster.ImageName;
                }
                objMemberMasterDAL.Phone2 = memberMaster.Phone2;
                objMemberMasterDAL.Phone1 = memberMaster.Phone1;
                objMemberMasterDAL.Email = memberMaster.Email;
                objMemberMasterDAL.Password = memberMaster.Password;
                objMemberMasterDAL.MemberType = memberMaster.MemberType;
                objMemberMasterDAL.LastLoginDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.Gender = memberMaster.Gender;
                objMemberMasterDAL.BirthDate = DateTime.ParseExact(memberMaster.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                if (memberMaster.FCMToken != null)
                {
                    objMemberMasterDAL.FCMToken = mymGlobalsDAL.DecodeString(memberMaster.FCMToken);
                }

                //Personal Detail
                objMemberMasterDAL.Qualification = memberMaster.Qualification;
                objMemberMasterDAL.BloodGroup = memberMaster.BloodGroup;
                objMemberMasterDAL.Profession = memberMaster.Profession;
                if (memberMaster.IsMarried)
                {
                    objMemberMasterDAL.AnniversaryDate = DateTime.ParseExact(memberMaster.AnniversaryDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                }

                List<mymMemberRelativesTranDAL> alMemberRelative = new List<mymMemberRelativesTranDAL>();
                if (memberMaster.lstMemberRelativeTran != null)
                {
                    mymMemberRelativesTranDAL objMemberRelativeTranDAL = null;
                    foreach (MemberRelativesTran memberRelativeTran in memberMaster.lstMemberRelativeTran)
                    {
                        objMemberRelativeTranDAL = new mymMemberRelativesTranDAL();
                        if (memberRelativeTran.MemberRelativesTranId != 0)
                        {
                            objMemberRelativeTranDAL.MemberRelativesTranId = memberRelativeTran.MemberRelativesTranId;
                        }
                        if (memberRelativeTran.ImageNameBytes != null)
                        {
                            if (!Directory.Exists(ImageSavePath))
                            {
                                Directory.CreateDirectory(ImageSavePath);
                            }
                            byte[] buffer = Convert.FromBase64String(memberRelativeTran.ImageNameBytes);
                            MemoryStream ms = new MemoryStream(buffer);
                            Image image = Image.FromStream(ms);
                            image.Save(ImageSavePathRelative + memberRelativeTran.ImageName);
                            objMemberRelativeTranDAL.ImageName = memberRelativeTran.ImageName;
                        }
                        objMemberRelativeTranDAL.linktoMemberMasterId = memberRelativeTran.linktoMemberMasterId;
                        objMemberRelativeTranDAL.RelativeName = memberRelativeTran.RelativeName;
                        objMemberRelativeTranDAL.Relation = memberRelativeTran.Relation;
                        objMemberRelativeTranDAL.Gender = memberRelativeTran.Gender;
                        objMemberRelativeTranDAL.BirthDate = DateTime.ParseExact(memberRelativeTran.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                        alMemberRelative.Add(objMemberRelativeTranDAL);
                    }
                    objMemberMasterDAL.lstMemberRelativeTranDAL = alMemberRelative;
                }

                //Contact Detail
                objMemberMasterDAL.LastLoginDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.HomeCountry = memberMaster.HomeCountry;
                objMemberMasterDAL.HomeState = memberMaster.HomeState;
                objMemberMasterDAL.HomeCity = memberMaster.HomeCity;
                objMemberMasterDAL.HomeArea = memberMaster.HomeArea;
                objMemberMasterDAL.HomeNumberStreet = memberMaster.HomeNumberStreet;
                objMemberMasterDAL.HomeZipCode = memberMaster.HomeZipCode;
                objMemberMasterDAL.HomeNearBy = memberMaster.HomeNearBy;
                objMemberMasterDAL.HomePhone = memberMaster.HomePhone;
                objMemberMasterDAL.OfficeCountry = memberMaster.OfficeCountry;
                objMemberMasterDAL.OfficeState = memberMaster.OfficeState;
                objMemberMasterDAL.OfficeCity = memberMaster.OfficeCity;
                objMemberMasterDAL.OfficeArea = memberMaster.OfficeArea;
                objMemberMasterDAL.OfficeNumberStreet = memberMaster.OfficeNumberStreet;
                objMemberMasterDAL.OfficeNearBy = memberMaster.OfficeNearBy;
                objMemberMasterDAL.OfficePhone = memberMaster.OfficePhone;
                objMemberMasterDAL.OfficeZipCode = memberMaster.OfficeZipCode;
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();

                mymRecordStatus rs = objMemberMasterDAL.InsertMemberMasterDetail();
                MemberMaster objMemberMaster = null;
                if (rs == mymRecordStatus.Success)
                {
                    objMemberMaster = new MemberMaster();
                    objMemberMaster.SetClassObject(objMemberMasterDAL);
                }
                else if (rs == mymRecordStatus.RecordAlreadyExist)
                {
                    objMemberMaster = new MemberMaster();
                    objMemberMaster.errorCode = "-2";
                }
                return objMemberMaster;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                MemberMaster objMemberMaster = null;
                return objMemberMaster;
            }
        }

        public NotificationMaster InsertNotificationMaster(NotificationMaster notificationMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Notification/";
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "Notification\\";
            try
            {
                mymNotificationMasterDAL objNotificationMasterDAL = new mymNotificationMasterDAL();

                objNotificationMasterDAL.NotificationTitle = notificationMaster.NotificationTitle;
                objNotificationMasterDAL.NotificationText = notificationMaster.NotificationText;
                if (notificationMaster.NotificationImageNameBytes != null)
                {
                    if (!Directory.Exists(ImageSavePath))
                    {
                        Directory.CreateDirectory(ImageSavePath);
                    }
                    byte[] buffer = Convert.FromBase64String(notificationMaster.NotificationImageNameBytes);
                    MemoryStream ms = new MemoryStream(buffer);
                    Image image = Image.FromStream(ms);
                    image.Save(ImageSavePath + notificationMaster.NotificationImageName);
                }
                objNotificationMasterDAL.linktoMemberMasterIdCreatedBy = notificationMaster.linktoMemberMasterIdCreatedBy;
                objNotificationMasterDAL.IsDeleted = notificationMaster.IsDeleted;
                objNotificationMasterDAL.NotificationImageName = notificationMaster.NotificationImageName;
                objNotificationMasterDAL.NotificationDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objNotificationMasterDAL.CreateDateTime = mymGlobalsDAL.GetCurrentDateTime();

                mymRecordStatus rs = objNotificationMasterDAL.InsertNotificationMaster();
                objErrorStatus.ErrorCode = (int)rs;
                if (rs == mymRecordStatus.Success)
                {
                    notificationMaster.NotificationMasterId = objNotificationMasterDAL.NotificationMasterId;
                    return notificationMaster;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return null;
            }
        }

        public ErrorStatus InsertAdvertiseMaster(AdvertiseMaster advertiseMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Advertise/";
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "Advertise\\";
            try
            {
                mymAdvertiseMasterDAL objAdvertiseMasterDAL = new mymAdvertiseMasterDAL();

                objAdvertiseMasterDAL.AdvertiseText = advertiseMaster.AdvertiseText;
                if (advertiseMaster.AdvertiseImageNameBytes != null)
                {
                    if (!Directory.Exists(ImageSavePath))
                    {
                        Directory.CreateDirectory(ImageSavePath);
                    }
                    byte[] buffer = Convert.FromBase64String(advertiseMaster.AdvertiseImageNameBytes);
                    MemoryStream ms = new MemoryStream(buffer);
                    Image image = Image.FromStream(ms);
                    image.Save(ImageSavePath + advertiseMaster.AdvertiseImageName);
                    objAdvertiseMasterDAL.AdvertiseImageName = advertiseMaster.AdvertiseImageName;
                }
                objAdvertiseMasterDAL.WebsiteURL = advertiseMaster.WebsiteURL;
                objAdvertiseMasterDAL.AdvertisementType = advertiseMaster.AdvertisementType;
                objAdvertiseMasterDAL.linktoMemberMasterIdCreatedBy = advertiseMaster.linktoMemberMasterIdCreatedBy;
                objAdvertiseMasterDAL.CreateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objAdvertiseMasterDAL.IsEnabled = advertiseMaster.IsEnabled;
                objAdvertiseMasterDAL.IsDeleted = advertiseMaster.IsDeleted;

                mymRecordStatus rs = objAdvertiseMasterDAL.InsertAdvertiseMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertNotificationTran(NotificationTran notificationTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymNotificationTranDAL objNotificationTranDAL = new mymNotificationTranDAL();

                objNotificationTranDAL.linktoNotificationMasterId = notificationTran.linktoNotificationMasterId;
                objNotificationTranDAL.linktoMemberMasterId = notificationTran.linktoMemberMasterId;
                objNotificationTranDAL.ReadDateTime = mymGlobalsDAL.GetCurrentDateTime();

                mymRecordStatus rs = objNotificationTranDAL.InsertNotificationTran();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        #endregion

        #region Update
        public ErrorStatus UpdateMemberMaster(MemberMaster memberMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = memberMaster.MemberMasterId;
                objMemberMasterDAL.MemberName = memberMaster.MemberName;
                objMemberMasterDAL.Phone1 = memberMaster.Phone1;
                objMemberMasterDAL.Phone2 = memberMaster.Phone2;
                objMemberMasterDAL.Email = memberMaster.Email;
                objMemberMasterDAL.Password = memberMaster.Password;
                objMemberMasterDAL.MemberType = memberMaster.MemberType;
                objMemberMasterDAL.LastLoginDateTime = DateTime.ParseExact(memberMaster.LastLoginDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objMemberMasterDAL.Gender = memberMaster.Gender;
                objMemberMasterDAL.Qualification = memberMaster.Qualification;
                objMemberMasterDAL.BloodGroup = memberMaster.BloodGroup;
                objMemberMasterDAL.Profession = memberMaster.Profession;
                objMemberMasterDAL.BirthDate = DateTime.ParseExact(memberMaster.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objMemberMasterDAL.AnniversaryDate = DateTime.ParseExact(memberMaster.AnniversaryDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objMemberMasterDAL.HomeCountry = memberMaster.HomeCountry;
                objMemberMasterDAL.HomeState = memberMaster.HomeState;
                objMemberMasterDAL.HomeCity = memberMaster.HomeCity;
                objMemberMasterDAL.HomeArea = memberMaster.HomeArea;
                objMemberMasterDAL.HomeNumberStreet = memberMaster.HomeNumberStreet;
                objMemberMasterDAL.HomeNearBy = memberMaster.HomeNearBy;
                objMemberMasterDAL.HomePhone = memberMaster.HomePhone;
                objMemberMasterDAL.OfficeCountry = memberMaster.OfficeCountry;
                objMemberMasterDAL.OfficeState = memberMaster.OfficeState;
                objMemberMasterDAL.OfficeCity = memberMaster.OfficeCity;
                objMemberMasterDAL.OfficeArea = memberMaster.OfficeArea;
                objMemberMasterDAL.OfficeNumberStreet = memberMaster.OfficeNumberStreet;
                objMemberMasterDAL.OfficeNearBy = memberMaster.OfficeNearBy;
                objMemberMasterDAL.OfficePhone = memberMaster.OfficePhone;
                objMemberMasterDAL.IsApproved = memberMaster.IsApproved;
                objMemberMasterDAL.IsAdminNotificationSent = memberMaster.IsAdminNotificationSent;
                objMemberMasterDAL.IsMemberNotificationSent = memberMaster.IsMemberNotificationSent;
                objMemberMasterDAL.FCMToken = memberMaster.FCMToken;
                objMemberMasterDAL.linktoMemberMasterIdApprovedBy = memberMaster.linktoMemberMasterIdApprovedBy;
                objMemberMasterDAL.ApprovedDateTime = DateTime.ParseExact(memberMaster.ApprovedDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = memberMaster.linktoMemberMasterIdUpdatedBy;
                objMemberMasterDAL.UpdateDateTime = DateTime.ParseExact(memberMaster.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);

                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateMemberMasterByMemberMasterId(MemberMaster memberMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = memberMaster.MemberMasterId;
                objMemberMasterDAL.MemberName = memberMaster.MemberName;
                objMemberMasterDAL.Phone1 = memberMaster.Phone1;
                objMemberMasterDAL.Phone2 = memberMaster.Phone2;
                objMemberMasterDAL.Gender = memberMaster.Gender;
                objMemberMasterDAL.BirthDate = DateTime.ParseExact(memberMaster.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();

                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMasterByMemberMasterId();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public String UpdateMemberMasterImageByMemberMasterId(MemberMaster memberMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "Member\\";
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = memberMaster.MemberMasterId;
                if (memberMaster.ImageName != null)
                {
                    if (memberMaster.ImageNameBytes != null)
                    {
                        if (!Directory.Exists(ImageSavePath))
                        {
                            Directory.CreateDirectory(ImageSavePath);
                        }
                        byte[] buffer = Convert.FromBase64String(memberMaster.ImageNameBytes);
                        MemoryStream ms = new MemoryStream(buffer);
                        Image image = Image.FromStream(ms);
                        image.Save(ImageSavePath + memberMaster.ImageName);
                        objMemberMasterDAL.ImageName = memberMaster.ImageName;
                    }
                }
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();

                String rs = objMemberMasterDAL.UpdateMemberMasterImageByMemberMasterId();
                //objErrorStatus.ErrorCode = (int)rs;
                return rs;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                //objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return null;
            }
        }

        public ErrorStatus UpdateMemberMasterPersonalDetail(MemberMaster memberMaster)
        {
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "MemberRelative\\";
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = memberMaster.MemberMasterId;
                objMemberMasterDAL.LastLoginDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.Qualification = memberMaster.Qualification;
                objMemberMasterDAL.BloodGroup = memberMaster.BloodGroup;
                objMemberMasterDAL.Profession = memberMaster.Profession;
                if (memberMaster.IsMarried)
                {
                    objMemberMasterDAL.AnniversaryDate = DateTime.ParseExact(memberMaster.AnniversaryDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                }
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = memberMaster.MemberMasterId;
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();

                List<mymMemberRelativesTranDAL> alMemberRelative = new List<mymMemberRelativesTranDAL>();

                if (memberMaster.lstMemberRelativeTran != null)
                {
                    mymMemberRelativesTranDAL objMemberRelativeTranDAL = null;
                    foreach (MemberRelativesTran memberRelativeTran in memberMaster.lstMemberRelativeTran)
                    {
                        objMemberRelativeTranDAL = new mymMemberRelativesTranDAL();
                        if (memberRelativeTran.MemberRelativesTranId != 0)
                        {
                            objMemberRelativeTranDAL.MemberRelativesTranId = memberRelativeTran.MemberRelativesTranId;
                        }
                        if (memberRelativeTran.ImageNameBytes != null)
                        {
                            if (!Directory.Exists(ImageSavePath))
                            {
                                Directory.CreateDirectory(ImageSavePath);
                            }
                            byte[] buffer = Convert.FromBase64String(memberRelativeTran.ImageNameBytes);
                            MemoryStream ms = new MemoryStream(buffer);
                            Image image = Image.FromStream(ms);
                            image.Save(ImageSavePath + memberRelativeTran.ImageName);
                            objMemberRelativeTranDAL.ImageName = memberRelativeTran.ImageName;
                        }
                        objMemberRelativeTranDAL.linktoMemberMasterId = memberRelativeTran.linktoMemberMasterId;
                        objMemberRelativeTranDAL.RelativeName = memberRelativeTran.RelativeName;
                        objMemberRelativeTranDAL.Relation = memberRelativeTran.Relation;
                        objMemberRelativeTranDAL.Gender = memberRelativeTran.Gender;
                        objMemberRelativeTranDAL.BirthDate = DateTime.ParseExact(memberRelativeTran.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                        alMemberRelative.Add(objMemberRelativeTranDAL);
                    }
                    objMemberMasterDAL.lstMemberRelativeTranDAL = alMemberRelative;
                }

                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMasterPersonalDetail();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;

            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateMemberMasterContactDetail(MemberMaster memberMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = memberMaster.MemberMasterId;
                objMemberMasterDAL.LastLoginDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.HomeCountry = memberMaster.HomeCountry;
                objMemberMasterDAL.HomeState = memberMaster.HomeState;
                objMemberMasterDAL.HomeCity = memberMaster.HomeCity;
                objMemberMasterDAL.HomeArea = memberMaster.HomeArea;
                objMemberMasterDAL.HomeNumberStreet = memberMaster.HomeNumberStreet;
                objMemberMasterDAL.HomeZipCode = memberMaster.HomeZipCode;
                objMemberMasterDAL.HomeNearBy = memberMaster.HomeNearBy;
                objMemberMasterDAL.HomePhone = memberMaster.HomePhone;
                objMemberMasterDAL.OfficeCountry = memberMaster.OfficeCountry;
                objMemberMasterDAL.OfficeState = memberMaster.OfficeState;
                objMemberMasterDAL.OfficeCity = memberMaster.OfficeCity;
                objMemberMasterDAL.OfficeArea = memberMaster.OfficeArea;
                objMemberMasterDAL.OfficeNumberStreet = memberMaster.OfficeNumberStreet;
                objMemberMasterDAL.OfficeNearBy = memberMaster.OfficeNearBy;
                objMemberMasterDAL.OfficePhone = memberMaster.OfficePhone;
                objMemberMasterDAL.OfficeZipCode = memberMaster.OfficeZipCode;
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = memberMaster.MemberMasterId;
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();

                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMasterContactDetail();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateMemberMasterIsApproved(MemberMaster memberMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = memberMaster.MemberMasterId;
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.ApprovedDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.IsApproved = memberMaster.IsApproved;
                objMemberMasterDAL.linktoMemberMasterIdApprovedBy = memberMaster.linktoMemberMasterIdApprovedBy;
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = memberMaster.linktoMemberMasterIdUpdatedBy;

                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMasterIsApproved();
                objErrorStatus.ErrorCode = (int)rs;
                if (rs == mymRecordStatus.Success && memberMaster.IsApproved)
                {
                    objMemberMasterDAL.SelectMemberByMemberMasterId();
                    if (objMemberMasterDAL.FCMToken != null)
                    {
                        mymFCMPushNotificationDAL apnGCM = new mymFCMPushNotificationDAL();
                        string strResponse = apnGCM.SendNotification(objMemberMasterDAL.FCMToken, "Mahavir Yuvak Mandal", "Request approved. Please login to explore.", null, null, "Approved", null);
                    }
                }
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateAdvertiseMasterDisable(AdvertiseMaster advertiseMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymAdvertiseMasterDAL objAdvertiseMasterDAL = new mymAdvertiseMasterDAL();

                objAdvertiseMasterDAL.AdvertiseMasterId = advertiseMaster.AdvertiseMasterId;
                objAdvertiseMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objAdvertiseMasterDAL.linktoMemberMasterIdUpdatedBy = advertiseMaster.linktoMemberMasterIdUpdatedBy;
                objAdvertiseMasterDAL.IsEnabled = advertiseMaster.IsEnabled;

                mymRecordStatus rs = objAdvertiseMasterDAL.UpdateAdvertiseMasterDisable();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateAdvertiseMaster(AdvertiseMaster advertiseMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "Advertise/";
            string ImageSavePath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + "Advertise\\";
            try
            {
                mymAdvertiseMasterDAL objAdvertiseMasterDAL = new mymAdvertiseMasterDAL();

                objAdvertiseMasterDAL.AdvertiseMasterId = advertiseMaster.AdvertiseMasterId;
                objAdvertiseMasterDAL.AdvertiseText = advertiseMaster.AdvertiseText;
                if (advertiseMaster.AdvertiseImageNameBytes != null)
                {
                    if (!Directory.Exists(ImageSavePath))
                    {
                        Directory.CreateDirectory(ImageSavePath);
                    }
                    byte[] buffer = Convert.FromBase64String(advertiseMaster.AdvertiseImageNameBytes);
                    MemoryStream ms = new MemoryStream(buffer);
                    Image image = Image.FromStream(ms);
                    image.Save(ImageSavePath + advertiseMaster.AdvertiseImageName);
                    objAdvertiseMasterDAL.AdvertiseImageName = advertiseMaster.AdvertiseImageName;
                }
                objAdvertiseMasterDAL.WebsiteURL = advertiseMaster.WebsiteURL;
                objAdvertiseMasterDAL.AdvertisementType = advertiseMaster.AdvertisementType;
                objAdvertiseMasterDAL.linktoMemberMasterIdUpdatedBy = advertiseMaster.linktoMemberMasterIdUpdatedBy;
                objAdvertiseMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();

                mymRecordStatus rs = objAdvertiseMasterDAL.UpdateAdvertiseMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateAdvertiseMasterDelete(AdvertiseMaster advertiseMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymAdvertiseMasterDAL objAdvertiseMasterDAL = new mymAdvertiseMasterDAL();

                objAdvertiseMasterDAL.AdvertiseMasterId = advertiseMaster.AdvertiseMasterId;
                objAdvertiseMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objAdvertiseMasterDAL.linktoMemberMasterIdUpdatedBy = advertiseMaster.linktoMemberMasterIdUpdatedBy;
                objAdvertiseMasterDAL.IsDeleted = advertiseMaster.IsDeleted;

                mymRecordStatus rs = objAdvertiseMasterDAL.UpdateAdvertiseMasterDelete();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateMemberMasterAdmin(string memberMasterId, string memberType, string linktoMemberMasterIdUpdatedBy)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = Convert.ToInt16(memberMasterId);
                objMemberMasterDAL.MemberType = memberType;
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = Convert.ToInt16(linktoMemberMasterIdUpdatedBy);

                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMasterAdmin();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateMemberMasterPassword(string memberMasterId, string password, string confirmPassword)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = Convert.ToInt16(memberMasterId);
                objMemberMasterDAL.Password = password;
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = Convert.ToInt16(memberMasterId);
                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMasterPassword(confirmPassword);
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateMemberMasterLogOut(string memberMasterId)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = Convert.ToInt16(memberMasterId);
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = Convert.ToInt16(memberMasterId);
                mymRecordStatus rs = objMemberMasterDAL.UpdateMemberMasterLogOut();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }
        #endregion

        #region Delete

        public ErrorStatus DeleteMemberMasterByMemberMasterId(string memberMasterId, string isDelete, string linktoMemberMasterIdUpdatedBy)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = Convert.ToInt32(memberMasterId);
                objMemberMasterDAL.UpdateDateTime = mymGlobalsDAL.GetCurrentDateTime();
                objMemberMasterDAL.IsDeleted = Convert.ToBoolean(isDelete);
                objMemberMasterDAL.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(linktoMemberMasterIdUpdatedBy);

                mymRecordStatus rs = objMemberMasterDAL.DeleteMemberMasterByMemberMasterId();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }

        #endregion

        #region Select

        public MemberMaster SelectMemberMaster(string email, string password, string FCMToken)
        {
            mymMemberMasterDAL objMemberMasterDAL = null;
            try
            {
                objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.Email = mymGlobalsDAL.DecodeString(email);
                if (objMemberMasterDAL.SelectMemberMasterByEmail())
                {
                    if (!objMemberMasterDAL.Password.Equals(mymGlobalsDAL.DecodeString(password), StringComparison.InvariantCulture))
                    {
                        return null;
                    }
                    else
                    {
                        objMemberMasterDAL.LastLoginDateTime = mymGlobalsDAL.GetCurrentDateTime();
                        objMemberMasterDAL.UpdateUserMasterLastLoginDateTime();

                        if (FCMToken != null)
                        {
                            objMemberMasterDAL.FCMToken = mymGlobalsDAL.DecodeString(FCMToken);
                        }
                        objMemberMasterDAL.UpdateMemberMasterFCMToken();

                        MemberMaster objMemberMaster = new MemberMaster();
                        objMemberMaster.SetClassObject(objMemberMasterDAL);
                        return objMemberMaster;
                    }
                }
                else
                {
                    return null;

                }
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                objMemberMasterDAL = null;
            }
        }

        public MemberMaster SelectMemberByMemberMasterId(string memberMasterId)
        {
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();

                objMemberMasterDAL.MemberMasterId = Convert.ToInt32(memberMasterId);

                objMemberMasterDAL.SelectMemberByMemberMasterId();

                MemberMaster objMemberMaster = new MemberMaster();
                objMemberMaster.SetClassObject(objMemberMasterDAL);
                return objMemberMaster;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        #endregion

        #region SelectAll
        public List<MemberMaster> SelectAllMemberMasterPageWise(string memberMasterId, string currentPage, string pagesize)
        {
            List<MemberMaster> lstMemberMaster = new List<MemberMaster>();
            try
            {
                short PageSize = Convert.ToInt16(pagesize);
                short StartRowIndex = (short)(PageSize * (Convert.ToInt16(currentPage) - 1));
                short TotalRecords = 0;
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();
                objMemberMasterDAL.MemberMasterId = Convert.ToInt16(memberMasterId);
                lstMemberMaster = MemberMaster.SetListObject(objMemberMasterDAL.SelectAllMemberMasterPageWise(StartRowIndex, PageSize, out TotalRecords));
                return lstMemberMaster;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<MemberMaster> SelectAllMemberMasterFilterPageWise(string memberMasterId, string currentPage, string memberName, string profession, string qualification, string bloodGroup)
        {
            List<MemberMaster> lstMemberMaster = new List<MemberMaster>();
            try
            {
                short PageSize = 10;
                short StartRowIndex = (short)(PageSize * (Convert.ToInt16(currentPage) - 1));
                short TotalRecords = 0;
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();
                objMemberMasterDAL.MemberMasterId = Convert.ToInt16(memberMasterId);
                if (memberName != null && !memberName.Equals("null"))
                {
                    objMemberMasterDAL.MemberName = memberName;
                }
                if (profession != null && !profession.Equals("null"))
                {
                    objMemberMasterDAL.Profession = mymGlobalsDAL.DecodeString(profession);
                }
                if (qualification != null && !qualification.Equals("null"))
                {
                    objMemberMasterDAL.Qualification = mymGlobalsDAL.DecodeString(qualification);
                }
                if (bloodGroup != null && !bloodGroup.Equals("null"))
                {
                    objMemberMasterDAL.BloodGroup = mymGlobalsDAL.DecodeString(bloodGroup);
                }
                lstMemberMaster = MemberMaster.SetListObject(objMemberMasterDAL.SelectAllMemberMasterFilterPageWise(StartRowIndex, PageSize, out TotalRecords));
                return lstMemberMaster;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<MemberMaster> SelectAllNewMemberMasterPageWise(string currentPage)
        {
            List<MemberMaster> lstMemberMaster = new List<MemberMaster>();
            try
            {
                short PageSize = 10;
                short StartRowIndex = (short)(PageSize * (Convert.ToInt16(currentPage) - 1));
                short TotalRecords = 0;
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();
                lstMemberMaster = MemberMaster.SetListObject(objMemberMasterDAL.SelectAllNewMemberMasterPageWise(StartRowIndex, PageSize, out TotalRecords));
                return lstMemberMaster;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<NotificationMaster> SelectAllNotificationMasterPageWise(string currentPage, string memberMasterId)
        {
            List<NotificationMaster> lstNotificationMaster = new List<NotificationMaster>();
            try
            {
                short PageSize = 10;
                short StartRowIndex = (short)(PageSize * (Convert.ToInt16(currentPage) - 1));
                short TotalRecords = 0;
                mymNotificationMasterDAL objNotificationMasterDAL = new mymNotificationMasterDAL();
                lstNotificationMaster = NotificationMaster.SetListObject(objNotificationMasterDAL.SelectAllNotificationMasterPageWise(StartRowIndex, PageSize, Convert.ToInt16(memberMasterId), out TotalRecords));
                return lstNotificationMaster;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<AdvertiseMaster> SelectAllAdvertiseMasterPageWise(string currentPage, string pageSize)
        {
            List<AdvertiseMaster> lstAdvertiseMaster = new List<AdvertiseMaster>();
            try
            {
                short PageSize = Convert.ToInt16(pageSize);
                short StartRowIndex = (short)(PageSize * (Convert.ToInt16(currentPage) - 1));
                short TotalRecords = 0;
                mymAdvertiseMasterDAL objAdvertiseMasterDAL = new mymAdvertiseMasterDAL();
                if (PageSize == 1)
                {
                    objAdvertiseMasterDAL.IsEnabled = true;
                }
                lstAdvertiseMaster = AdvertiseMaster.SetListObject(objAdvertiseMasterDAL.SelectAllAdvertiseMasterPageWise(StartRowIndex, PageSize, out TotalRecords));
                return lstAdvertiseMaster;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<String> SelectAllProfession()
        {
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();
                List<string> Professions = objMemberMasterDAL.SelectAllProfession();

                string FileName = System.Configuration.ConfigurationManager.AppSettings["FileSavePath"] + "\\Professions.txt";
                if (File.Exists(FileName))
                {
                    string FileContent = File.ReadAllText(FileName);
                    if (!string.IsNullOrEmpty(FileContent))
                    {
                        Professions.AddRange(FileContent.Split(','));
                        Professions = Professions.Distinct().ToList();
                        Professions.Sort();
                    }
                }
                return Professions;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<String> SelectAllStates()
        {
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();
                List<string> States = new List<string>();

                string FileName = System.Configuration.ConfigurationManager.AppSettings["FileSavePath"] + "\\States.txt";
                if (File.Exists(FileName))
                {
                    string FileContent = File.ReadAllText(FileName);
                    if (!string.IsNullOrEmpty(FileContent))
                    {
                        States.AddRange(FileContent.Split(','));
                        States = States.Distinct().ToList();
                        States.Sort();
                    }
                }
                return States;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<String> SelectAllQualification()
        {
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();
                List<string> Qualifications = objMemberMasterDAL.SelectAllQualification();

                string FileName = System.Configuration.ConfigurationManager.AppSettings["FileSavePath"] + "\\Qualifications.txt";
                if (File.Exists(FileName))
                {
                    string FileContent = File.ReadAllText(FileName);
                    if (!string.IsNullOrEmpty(FileContent))
                    {
                        Qualifications.AddRange(FileContent.Split(','));
                    }
                }

                Qualifications = Qualifications.Distinct().ToList();
                Qualifications.Sort();

                return Qualifications;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                return null;
            }
        }
        #endregion

        #region SendNotifications

        public void SendNotificationsToAll(string notificationMasterId)
        {
            mymFCMPushNotificationDAL apnGCM = new mymFCMPushNotificationDAL();
            mymMemberMasterDAL objMemberMaster = new mymMemberMasterDAL();
            mymNotificationMasterDAL notificationMaster = new mymNotificationMasterDAL();
            List<mymMemberMasterDAL> lstMemberMaster = new List<mymMemberMasterDAL>();
            notificationMaster.NotificationMasterId = Convert.ToInt16(notificationMasterId);
            notificationMaster.SelectNotificationMaster();
            lstMemberMaster = objMemberMaster.SelectAllMemberMaster();

            string imageName = null;
            imageName = notificationMaster.NotificationImageName;

            if (imageName == null)
            {
                imageName = notificationMaster.NotificationImageName;
            }

            if (lstMemberMaster != null && lstMemberMaster.Count > 0)
            {
                foreach (mymMemberMasterDAL memberMaster in lstMemberMaster)
                {
                    if (memberMaster.FCMToken != null)
                    {
                        string strResponse = apnGCM.SendNotification(memberMaster.FCMToken, notificationMaster.NotificationTitle, notificationMaster.NotificationText, null, imageName, "Notification", null);
                    }
                }
            }
        }

        public void SendNotificationsNewRequest(string membermasterId)
        {
            mymFCMPushNotificationDAL apnGCM = new mymFCMPushNotificationDAL();
            mymMemberMasterDAL objMemberMaster = new mymMemberMasterDAL();
            List<mymMemberMasterDAL> lstMemberMaster = new List<mymMemberMasterDAL>();
            objMemberMaster.MemberMasterId = Convert.ToInt16(membermasterId);
            objMemberMaster.SelectMemberByMemberMasterId();
            lstMemberMaster = objMemberMaster.SelectAllMemberMaster();

            if (lstMemberMaster != null && lstMemberMaster.Count > 0)
            {
                foreach (mymMemberMasterDAL memberMaster in lstMemberMaster)
                {
                    if (memberMaster.FCMToken != null && memberMaster.MemberType.Equals("Admin"))
                    {
                        string strResponse = apnGCM.SendNotification(memberMaster.FCMToken, "New member request.", objMemberMaster.MemberName + "(" + objMemberMaster.HomeCity + ") - " + objMemberMaster.Profession, objMemberMaster.MemberName, null, "Request", objMemberMaster.MemberMasterId.ToString());
                    }
                }
            }
        }

        #endregion

        public ErrorStatus ForgotPasswordMemberMaster(string email)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                mymMemberMasterDAL objMemberMasterDAL = new mymMemberMasterDAL();
                objMemberMasterDAL.Email = mymGlobalsDAL.DecodeString(email);
                mymRecordStatus rs = objMemberMasterDAL.ForgotPasswordMemberMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                mymGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)mymRecordStatus.Error;
                return objErrorStatus;
            }
        }
    }
}
