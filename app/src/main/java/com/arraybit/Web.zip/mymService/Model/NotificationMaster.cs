using System;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Model for NotificationMaster
	/// </summary>
	public class NotificationMaster
	{
        public int NotificationMasterId { get; set; }
        public string NotificationTitle { get; set; }
        public string NotificationText { get; set; }
        public string NotificationImageName { get; set; }
        public string NotificationDateTime { get; set; }
        public string CreateDateTime { get; set; }
        public int linktoMemberMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public int linktoMemberMasterIdUpdatedBy { get; set; }
        public bool IsDeleted { get; set; }

        //Extras
        public string NotificationImageNameBytes { get; set; }	

		internal void SetClassObject(mymNotificationMasterDAL objNotificationMasterDAL)
		{
			this.NotificationMasterId = Convert.ToInt32(objNotificationMasterDAL.NotificationMasterId);
			this.NotificationTitle = Convert.ToString(objNotificationMasterDAL.NotificationTitle);
			this.NotificationText = Convert.ToString(objNotificationMasterDAL.NotificationText);
			this.NotificationImageName = Convert.ToString(objNotificationMasterDAL.NotificationImageName);
			this.NotificationDateTime = objNotificationMasterDAL.NotificationDateTime.ToString("s");
			this.CreateDateTime = objNotificationMasterDAL.CreateDateTime.ToString("s");
			this.linktoMemberMasterIdCreatedBy = Convert.ToInt32(objNotificationMasterDAL.linktoMemberMasterIdCreatedBy);
			if (objNotificationMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objNotificationMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objNotificationMasterDAL.linktoMemberMasterIdUpdatedBy != null)
			{
				this.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(objNotificationMasterDAL.linktoMemberMasterIdUpdatedBy.Value);
			}
			this.IsDeleted = Convert.ToBoolean(objNotificationMasterDAL.IsDeleted);

			
		}

		internal static List<NotificationMaster> SetListObject(List<mymNotificationMasterDAL> lstNotificationMasterDAL)
		{
			List<NotificationMaster> lstNotificationMaster = new List<NotificationMaster>();
			NotificationMaster objNotificationMaster = null;
			foreach (mymNotificationMasterDAL objNotificationMasterDAL in lstNotificationMasterDAL)
			{
				objNotificationMaster = new NotificationMaster();
				objNotificationMaster.NotificationMasterId = Convert.ToInt32(objNotificationMasterDAL.NotificationMasterId);
				objNotificationMaster.NotificationTitle = Convert.ToString(objNotificationMasterDAL.NotificationTitle);
				objNotificationMaster.NotificationText = Convert.ToString(objNotificationMasterDAL.NotificationText);
				objNotificationMaster.NotificationImageName = Convert.ToString(objNotificationMasterDAL.NotificationImageName);
				objNotificationMaster.NotificationDateTime = objNotificationMasterDAL.NotificationDateTime.ToString("s");
				objNotificationMaster.CreateDateTime = objNotificationMasterDAL.CreateDateTime.ToString("s");
				objNotificationMaster.linktoMemberMasterIdCreatedBy = Convert.ToInt32(objNotificationMasterDAL.linktoMemberMasterIdCreatedBy);
				if (objNotificationMasterDAL.UpdateDateTime != null)
				{
					objNotificationMaster.UpdateDateTime = objNotificationMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objNotificationMasterDAL.linktoMemberMasterIdUpdatedBy != null)
				{
					objNotificationMaster.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(objNotificationMasterDAL.linktoMemberMasterIdUpdatedBy.Value);
				}
				objNotificationMaster.IsDeleted = Convert.ToBoolean(objNotificationMasterDAL.IsDeleted);
	
				lstNotificationMaster.Add(objNotificationMaster);
			}
			return lstNotificationMaster;
		}
	}
}
