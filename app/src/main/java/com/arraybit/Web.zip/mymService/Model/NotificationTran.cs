using System;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Model for NotificationTran
	/// </summary>
	public class NotificationTran
	{
        public long NotificationTranId { get; set; }
        public int linktoNotificationMasterId { get; set; }
        public int linktoMemberMasterId { get; set; }
        public string ReadDateTime { get; set; }
		/// Extra
		public int Notification { get; set; }
		public int Member { get; set; }


		internal void SetClassObject(mymNotificationTranDAL objNotificationTranDAL)
		{
			this.NotificationTranId = Convert.ToInt64(objNotificationTranDAL.NotificationTranId);
			this.linktoNotificationMasterId = Convert.ToInt32(objNotificationTranDAL.linktoNotificationMasterId);
			this.linktoMemberMasterId = Convert.ToInt32(objNotificationTranDAL.linktoMemberMasterId);
			this.ReadDateTime = objNotificationTranDAL.ReadDateTime.ToString("s");

			/// Extra
			this.Notification = Convert.ToInt32(objNotificationTranDAL.Notification);
			this.Member = Convert.ToInt32(objNotificationTranDAL.Member);
		}

		internal static List<NotificationTran> SetListObject(List<mymNotificationTranDAL> lstNotificationTranDAL)
		{
			List<NotificationTran> lstNotificationTran = new List<NotificationTran>();
			NotificationTran objNotificationTran = null;
			foreach (mymNotificationTranDAL objNotificationTranDAL in lstNotificationTranDAL)
			{
				objNotificationTran = new NotificationTran();
				objNotificationTran.NotificationTranId = Convert.ToInt64(objNotificationTranDAL.NotificationTranId);
				objNotificationTran.linktoNotificationMasterId = Convert.ToInt32(objNotificationTranDAL.linktoNotificationMasterId);
				objNotificationTran.linktoMemberMasterId = Convert.ToInt32(objNotificationTranDAL.linktoMemberMasterId);
				objNotificationTran.ReadDateTime = objNotificationTranDAL.ReadDateTime.ToString("s");

				/// Extra
				objNotificationTran.Notification = Convert.ToInt32(objNotificationTranDAL.Notification);
				objNotificationTran.Member = Convert.ToInt32(objNotificationTranDAL.Member);
				lstNotificationTran.Add(objNotificationTran);
			}
			return lstNotificationTran;
		}
	}
}
