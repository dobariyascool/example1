using System;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Model for MemberMaster
	/// </summary>
	public class MemberMaster
	{

        public int MemberMasterId { get; set; }
        public string MemberName { get; set; }
        public string ImageName { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string MemberType { get; set; }
        public string LastLoginDateTime { get; set; }
        public string Gender { get; set; }
        public string Qualification { get; set; }
        public string BloodGroup { get; set; }
        public string Profession { get; set; }
        public string BirthDate { get; set; }
        public string AnniversaryDate { get; set; }
        public string HomeCountry { get; set; }
        public string HomeState { get; set; }
        public string HomeCity { get; set; }
        public string HomeArea { get; set; }
        public string HomeNumberStreet { get; set; }
        public string HomeNearBy { get; set; }
        public string HomeZipCode { get; set; }
        public string HomePhone { get; set; }
        public string OfficeCountry { get; set; }
        public string OfficeState { get; set; }
        public string OfficeCity { get; set; }
        public string OfficeArea { get; set; }
        public string OfficeNumberStreet { get; set; }
        public string OfficeNearBy { get; set; }
        public string OfficeZipCode { get; set; }
        public string OfficePhone { get; set; }
        public bool IsApproved { get; set; }
        public bool IsAdminNotificationSent { get; set; }
        public bool IsMemberNotificationSent { get; set; }
        public string FCMToken { get; set; }
        public int linktoMemberMasterIdApprovedBy { get; set; }
        public string ApprovedDateTime { get; set; }
        public int linktoMemberMasterIdUpdatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public bool IsDeleted { get; set; }
        /// Extra
        public string ImageNameBytes { get; set; }
        public string errorCode { get; set; }
        public bool IsMarried { get; set; }
        public List<MemberRelativesTran> lstMemberRelativeTran { get; set; }

		internal void SetClassObject(mymMemberMasterDAL objMemberMasterDAL)
		{
			this.MemberMasterId = Convert.ToInt32(objMemberMasterDAL.MemberMasterId);
			this.MemberName = Convert.ToString(objMemberMasterDAL.MemberName);
            this.ImageName = Convert.ToString(objMemberMasterDAL.ImageName);
            this.Phone1 = Convert.ToString(objMemberMasterDAL.Phone1);
			this.Phone2 = Convert.ToString(objMemberMasterDAL.Phone2);
			this.Email = Convert.ToString(objMemberMasterDAL.Email);
			this.Password = Convert.ToString(objMemberMasterDAL.Password);
			this.MemberType = Convert.ToString(objMemberMasterDAL.MemberType);
			this.LastLoginDateTime = objMemberMasterDAL.LastLoginDateTime.ToString("s");
			this.Gender = Convert.ToString(objMemberMasterDAL.Gender);
			this.Qualification = Convert.ToString(objMemberMasterDAL.Qualification);
			this.BloodGroup = Convert.ToString(objMemberMasterDAL.BloodGroup);
			this.Profession = Convert.ToString(objMemberMasterDAL.Profession);
			if (objMemberMasterDAL.BirthDate != null)
			{
				this.BirthDate = objMemberMasterDAL.BirthDate.Value.ToString("yyyy-MM-dd");
			}
			if (objMemberMasterDAL.AnniversaryDate != null)
			{
				this.AnniversaryDate = objMemberMasterDAL.AnniversaryDate.Value.ToString("yyyy-MM-dd");
			}
			this.HomeCountry = Convert.ToString(objMemberMasterDAL.HomeCountry);
			this.HomeState = Convert.ToString(objMemberMasterDAL.HomeState);
			this.HomeCity = Convert.ToString(objMemberMasterDAL.HomeCity);
			this.HomeArea = Convert.ToString(objMemberMasterDAL.HomeArea);
			this.HomeNumberStreet = Convert.ToString(objMemberMasterDAL.HomeNumberStreet);
			this.HomeNearBy = Convert.ToString(objMemberMasterDAL.HomeNearBy);
            this.HomeZipCode = Convert.ToString(objMemberMasterDAL.HomeZipCode);
            this.HomePhone = Convert.ToString(objMemberMasterDAL.HomePhone);
			this.OfficeCountry = Convert.ToString(objMemberMasterDAL.OfficeCountry);
			this.OfficeState = Convert.ToString(objMemberMasterDAL.OfficeState);
			this.OfficeCity = Convert.ToString(objMemberMasterDAL.OfficeCity);
			this.OfficeArea = Convert.ToString(objMemberMasterDAL.OfficeArea);
			this.OfficeNumberStreet = Convert.ToString(objMemberMasterDAL.OfficeNumberStreet);
			this.OfficeNearBy = Convert.ToString(objMemberMasterDAL.OfficeNearBy);
            this.OfficeZipCode = Convert.ToString(objMemberMasterDAL.OfficeZipCode);
            this.OfficePhone = Convert.ToString(objMemberMasterDAL.OfficePhone);
			if (objMemberMasterDAL.IsApproved != null)
			{
				this.IsApproved = Convert.ToBoolean(objMemberMasterDAL.IsApproved.Value);
			}
			this.IsAdminNotificationSent = Convert.ToBoolean(objMemberMasterDAL.IsAdminNotificationSent);
			this.IsMemberNotificationSent = Convert.ToBoolean(objMemberMasterDAL.IsMemberNotificationSent);
			this.FCMToken = Convert.ToString(objMemberMasterDAL.FCMToken);
			this.linktoMemberMasterIdApprovedBy = Convert.ToInt32(objMemberMasterDAL.linktoMemberMasterIdApprovedBy);
            if (objMemberMasterDAL.ApprovedDateTime != null)
            {
                this.ApprovedDateTime = objMemberMasterDAL.ApprovedDateTime.Value.ToString("s");
            }
			if (objMemberMasterDAL.linktoMemberMasterIdUpdatedBy != null)
			{
				this.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(objMemberMasterDAL.linktoMemberMasterIdUpdatedBy.Value);
			}
			if (objMemberMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objMemberMasterDAL.UpdateDateTime.Value.ToString("s");
			}
            if (objMemberMasterDAL.lstMemberRelativeTranDAL!= null)
            { 
                MemberRelativesTran objMemberRelativeTran = new MemberRelativesTran();
                this.lstMemberRelativeTran = objMemberRelativeTran.SetListObject(objMemberMasterDAL.lstMemberRelativeTranDAL);
            }
		}

		internal static List<MemberMaster> SetListObject(List<mymMemberMasterDAL> lstMemberMasterDAL)
		{
			List<MemberMaster> lstMemberMaster = new List<MemberMaster>();
			MemberMaster objMemberMaster = null;
			foreach (mymMemberMasterDAL objMemberMasterDAL in lstMemberMasterDAL)
			{
				objMemberMaster = new MemberMaster();
				objMemberMaster.MemberMasterId = Convert.ToInt32(objMemberMasterDAL.MemberMasterId);
				objMemberMaster.MemberName = Convert.ToString(objMemberMasterDAL.MemberName);
                objMemberMaster.ImageName = Convert.ToString(objMemberMasterDAL.ImageName);
                objMemberMaster.Phone1 = Convert.ToString(objMemberMasterDAL.Phone1);
				objMemberMaster.Phone2 = Convert.ToString(objMemberMasterDAL.Phone2);
				objMemberMaster.Email = Convert.ToString(objMemberMasterDAL.Email);
				objMemberMaster.Password = Convert.ToString(objMemberMasterDAL.Password);
				objMemberMaster.MemberType = Convert.ToString(objMemberMasterDAL.MemberType);
				objMemberMaster.LastLoginDateTime = objMemberMasterDAL.LastLoginDateTime.ToString("s");
				objMemberMaster.Gender = Convert.ToString(objMemberMasterDAL.Gender);
				objMemberMaster.Qualification = Convert.ToString(objMemberMasterDAL.Qualification);
				objMemberMaster.BloodGroup = Convert.ToString(objMemberMasterDAL.BloodGroup);
				objMemberMaster.Profession = Convert.ToString(objMemberMasterDAL.Profession);
				if (objMemberMasterDAL.BirthDate != null)
				{
					objMemberMaster.BirthDate = objMemberMasterDAL.BirthDate.Value.ToString("yyyy-MM-dd");
				}
				if (objMemberMasterDAL.AnniversaryDate != null)
				{
					objMemberMaster.AnniversaryDate = objMemberMasterDAL.AnniversaryDate.Value.ToString("yyyy-MM-dd");
				}
				objMemberMaster.HomeCountry = Convert.ToString(objMemberMasterDAL.HomeCountry);
				objMemberMaster.HomeState = Convert.ToString(objMemberMasterDAL.HomeState);
				objMemberMaster.HomeCity = Convert.ToString(objMemberMasterDAL.HomeCity);
				objMemberMaster.HomeArea = Convert.ToString(objMemberMasterDAL.HomeArea);
				objMemberMaster.HomeNumberStreet = Convert.ToString(objMemberMasterDAL.HomeNumberStreet);
				objMemberMaster.HomeNearBy = Convert.ToString(objMemberMasterDAL.HomeNearBy);
                objMemberMaster.HomeZipCode = Convert.ToString(objMemberMasterDAL.HomeZipCode);
				objMemberMaster.HomePhone = Convert.ToString(objMemberMasterDAL.HomePhone);
				objMemberMaster.OfficeCountry = Convert.ToString(objMemberMasterDAL.OfficeCountry);
				objMemberMaster.OfficeState = Convert.ToString(objMemberMasterDAL.OfficeState);
				objMemberMaster.OfficeCity = Convert.ToString(objMemberMasterDAL.OfficeCity);
				objMemberMaster.OfficeArea = Convert.ToString(objMemberMasterDAL.OfficeArea);
				objMemberMaster.OfficeNumberStreet = Convert.ToString(objMemberMasterDAL.OfficeNumberStreet);
				objMemberMaster.OfficeNearBy = Convert.ToString(objMemberMasterDAL.OfficeNearBy);
                objMemberMaster.OfficeZipCode = Convert.ToString(objMemberMasterDAL.OfficeZipCode);
                objMemberMaster.OfficePhone = Convert.ToString(objMemberMasterDAL.OfficePhone);
				if (objMemberMasterDAL.IsApproved != null)
				{
					objMemberMaster.IsApproved = Convert.ToBoolean(objMemberMasterDAL.IsApproved.Value);
				}
				objMemberMaster.IsAdminNotificationSent = Convert.ToBoolean(objMemberMasterDAL.IsAdminNotificationSent);
				objMemberMaster.IsMemberNotificationSent = Convert.ToBoolean(objMemberMasterDAL.IsMemberNotificationSent);
				objMemberMaster.FCMToken = Convert.ToString(objMemberMasterDAL.FCMToken);
                if (objMemberMasterDAL.linktoMemberMasterIdApprovedBy != null)
                {
                    objMemberMaster.linktoMemberMasterIdApprovedBy = Convert.ToInt32(objMemberMasterDAL.linktoMemberMasterIdApprovedBy);
                }
                if (objMemberMasterDAL.ApprovedDateTime != null)
                {
                    objMemberMaster.ApprovedDateTime = objMemberMasterDAL.ApprovedDateTime.Value.ToString("s");
                }
				if (objMemberMasterDAL.linktoMemberMasterIdUpdatedBy != null)
				{
					objMemberMaster.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(objMemberMasterDAL.linktoMemberMasterIdUpdatedBy.Value);
				}
				if (objMemberMasterDAL.UpdateDateTime != null)
				{
					objMemberMaster.UpdateDateTime = objMemberMasterDAL.UpdateDateTime.Value.ToString("s");
				}              

				lstMemberMaster.Add(objMemberMaster);
			}
			return lstMemberMaster;
		}
	}
}
