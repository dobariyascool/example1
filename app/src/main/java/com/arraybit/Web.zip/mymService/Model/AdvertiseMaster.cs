using System;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Model for AdvertiseMaster
	/// </summary>
	public class AdvertiseMaster
	{
        public int AdvertiseMasterId { get; set; }
        public string AdvertiseText { get; set; }
        public string AdvertiseImageName { get; set; }
        public string WebsiteURL { get; set; }
        public string AdvertisementType { get; set; }
        public int linktoMemberMasterIdCreatedBy { get; set; }
        public string CreateDateTime { get; set; }
        public int linktoMemberMasterIdUpdatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
		/// Extra
        public string AdvertiseImageNameBytes { get; set; }	

		internal void SetClassObject(mymAdvertiseMasterDAL objAdvertiseMasterDAL)
		{
			this.AdvertiseMasterId = Convert.ToInt32(objAdvertiseMasterDAL.AdvertiseMasterId);
			this.AdvertiseText = Convert.ToString(objAdvertiseMasterDAL.AdvertiseText);
			this.AdvertiseImageName = Convert.ToString(objAdvertiseMasterDAL.AdvertiseImageName);
			this.WebsiteURL = Convert.ToString(objAdvertiseMasterDAL.WebsiteURL);
			this.AdvertisementType = Convert.ToString(objAdvertiseMasterDAL.AdvertisementType);
			this.linktoMemberMasterIdCreatedBy = Convert.ToInt32(objAdvertiseMasterDAL.linktoMemberMasterIdCreatedBy);
			this.CreateDateTime = objAdvertiseMasterDAL.CreateDateTime.ToString("s");
			if (objAdvertiseMasterDAL.linktoMemberMasterIdUpdatedBy != null)
			{
				this.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(objAdvertiseMasterDAL.linktoMemberMasterIdUpdatedBy.Value);
			}
			if (objAdvertiseMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objAdvertiseMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			this.IsEnabled = Convert.ToBoolean(objAdvertiseMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objAdvertiseMasterDAL.IsDeleted);
	
		}

		internal static List<AdvertiseMaster> SetListObject(List<mymAdvertiseMasterDAL> lstAdvertiseMasterDAL)
		{
			List<AdvertiseMaster> lstAdvertiseMaster = new List<AdvertiseMaster>();
			AdvertiseMaster objAdvertiseMaster = null;
			foreach (mymAdvertiseMasterDAL objAdvertiseMasterDAL in lstAdvertiseMasterDAL)
			{
				objAdvertiseMaster = new AdvertiseMaster();
				objAdvertiseMaster.AdvertiseMasterId = Convert.ToInt32(objAdvertiseMasterDAL.AdvertiseMasterId);
				objAdvertiseMaster.AdvertiseText = Convert.ToString(objAdvertiseMasterDAL.AdvertiseText);
				objAdvertiseMaster.AdvertiseImageName = Convert.ToString(objAdvertiseMasterDAL.AdvertiseImageName);
				objAdvertiseMaster.WebsiteURL = Convert.ToString(objAdvertiseMasterDAL.WebsiteURL);
				objAdvertiseMaster.AdvertisementType = Convert.ToString(objAdvertiseMasterDAL.AdvertisementType);
				objAdvertiseMaster.linktoMemberMasterIdCreatedBy = Convert.ToInt32(objAdvertiseMasterDAL.linktoMemberMasterIdCreatedBy);
				objAdvertiseMaster.CreateDateTime = objAdvertiseMasterDAL.CreateDateTime.ToString("s");
				if (objAdvertiseMasterDAL.linktoMemberMasterIdUpdatedBy != null)
				{
					objAdvertiseMaster.linktoMemberMasterIdUpdatedBy = Convert.ToInt32(objAdvertiseMasterDAL.linktoMemberMasterIdUpdatedBy.Value);
				}
				if (objAdvertiseMasterDAL.UpdateDateTime != null)
				{
					objAdvertiseMaster.UpdateDateTime = objAdvertiseMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				objAdvertiseMaster.IsEnabled = Convert.ToBoolean(objAdvertiseMasterDAL.IsEnabled);
				objAdvertiseMaster.IsDeleted = Convert.ToBoolean(objAdvertiseMasterDAL.IsDeleted);
			
				lstAdvertiseMaster.Add(objAdvertiseMaster);
			}
			return lstAdvertiseMaster;
		}
	}
}
