using System;
using System.Collections.Generic;

namespace mymLibrary
{
	/// <summary>
	/// Model for MemberRelativesTran
	/// </summary>
	public class MemberRelativesTran
	{
        public int MemberRelativesTranId { get; set; }
        public int linktoMemberMasterId { get; set; }
        public string RelativeName { get; set; }
        public string ImageName { get; set; }
        public string Gender { get; set; }
        public string BirthDate { get; set; }
        public string Relation { get; set; }
		/// Extra
        public string ImageNameBytes { get; set; }

		internal void SetClassObject(mymMemberRelativesTranDAL objMemberRelativesTranDAL)
		{
			this.MemberRelativesTranId = Convert.ToInt32(objMemberRelativesTranDAL.MemberRelativesTranId);
			this.linktoMemberMasterId = Convert.ToInt32(objMemberRelativesTranDAL.linktoMemberMasterId);
			this.RelativeName = Convert.ToString(objMemberRelativesTranDAL.RelativeName);
            this.ImageName = Convert.ToString(objMemberRelativesTranDAL.ImageName);
            this.Gender = Convert.ToString(objMemberRelativesTranDAL.Gender);
			if (objMemberRelativesTranDAL.BirthDate != null)
			{
				this.BirthDate = objMemberRelativesTranDAL.BirthDate.Value.ToString("yyyy-MM-dd");
			}
			this.Relation = Convert.ToString(objMemberRelativesTranDAL.Relation);

			/// Extra
		}

		internal List<MemberRelativesTran> SetListObject(List<mymMemberRelativesTranDAL> lstMemberRelativesTranDAL)
		{
			List<MemberRelativesTran> lstMemberRelativesTran = new List<MemberRelativesTran>();
			MemberRelativesTran objMemberRelativesTran = null;
			foreach (mymMemberRelativesTranDAL objMemberRelativesTranDAL in lstMemberRelativesTranDAL)
			{
				objMemberRelativesTran = new MemberRelativesTran();
				objMemberRelativesTran.MemberRelativesTranId = Convert.ToInt32(objMemberRelativesTranDAL.MemberRelativesTranId);
				objMemberRelativesTran.linktoMemberMasterId = Convert.ToInt32(objMemberRelativesTranDAL.linktoMemberMasterId);
				objMemberRelativesTran.RelativeName = Convert.ToString(objMemberRelativesTranDAL.RelativeName);
                objMemberRelativesTran.ImageName = Convert.ToString(objMemberRelativesTranDAL.ImageName);
                objMemberRelativesTran.Gender = Convert.ToString(objMemberRelativesTranDAL.Gender);
				if (objMemberRelativesTranDAL.BirthDate != null)
				{
					objMemberRelativesTran.BirthDate = objMemberRelativesTranDAL.BirthDate.Value.ToString("yyyy-MM-dd");
				}
				objMemberRelativesTran.Relation = Convert.ToString(objMemberRelativesTranDAL.Relation);

				/// Extra
				lstMemberRelativesTran.Add(objMemberRelativesTran);
			}
			return lstMemberRelativesTran;
		}
	}
}
