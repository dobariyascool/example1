﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using mymLibrary;

namespace mymService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService
    {
        
        [OperationContract]
        [WebInvoke(UriTemplate = "InsertMemberMasterDetail", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        MemberMaster InsertMemberMasterDetail(MemberMaster memberMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertNotificationMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        NotificationMaster InsertNotificationMaster(NotificationMaster notificationMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertAdvertiseMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertAdvertiseMaster(AdvertiseMaster advertiseMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertNotificationTran", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertNotificationTran(NotificationTran notificationTran);
        
        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateMemberMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMaster(MemberMaster memberMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateMemberMasterPersonalDetail", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMasterPersonalDetail(MemberMaster memberMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateMemberMasterContactDetail", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMasterContactDetail(MemberMaster memberMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateMemberMasterByMemberMasterId", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMasterByMemberMasterId(MemberMaster memberMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateMemberMasterImageByMemberMasterId", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        String UpdateMemberMasterImageByMemberMasterId(MemberMaster memberMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateMemberMasterIsApproved", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMasterIsApproved(MemberMaster memberMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateAdvertiseMasterDisable", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateAdvertiseMasterDisable(AdvertiseMaster advertiseMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateAdvertiseMasterDelete", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateAdvertiseMasterDelete(AdvertiseMaster advertiseMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateAdvertiseMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateAdvertiseMaster(AdvertiseMaster advertiseMaster);

        [OperationContract]
        [WebGet(UriTemplate = "UpdateMemberMasterAdmin/{memberMasterId}/{memberType}/{linktoMemberMasterIdUpdatedBy}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMasterAdmin(string memberMasterId, string memberType, string linktoMemberMasterIdUpdatedBy);

        [OperationContract]
        [WebGet(UriTemplate = "UpdateMemberMasterPassword/{memberMasterId}/{password}/{confirmPassword}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMasterPassword(string memberMasterId, string password, string confirmPassword);

        [OperationContract]
        [WebGet(UriTemplate = "UpdateMemberMasterLogOut/{memberMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateMemberMasterLogOut(string memberMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "DeleteMemberMasterByMemberMasterId/{memberMasterId}/{isDelete}/{linktoMemberMasterIdUpdatedBy}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus DeleteMemberMasterByMemberMasterId(string memberMasterId, string isDelete, string linktoMemberMasterIdUpdatedBy);

        [OperationContract]
        [WebGet(UriTemplate = "SelectMemberMaster/{email}/{password}/{FCMToken}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        MemberMaster SelectMemberMaster(string email, string password, string FCMToken);

        [OperationContract]
        [WebGet(UriTemplate = "SelectMemberByMemberMasterId/{memberMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        MemberMaster SelectMemberByMemberMasterId(string memberMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllMemberMasterPageWise/{memberMasterId}/{currentPage}/{pagesize}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<MemberMaster> SelectAllMemberMasterPageWise(string memberMasterId, string currentPage, string pagesize);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllMemberMasterFilterPageWise/{memberMasterId}/{currentPage}/{memberName}/{profession}/{qualification}/{bloodGroup}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<MemberMaster> SelectAllMemberMasterFilterPageWise(string memberMasterId, string currentPage, string memberName, string profession, string qualification, string bloodGroup);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllNewMemberMasterPageWise/{currentPage}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<MemberMaster> SelectAllNewMemberMasterPageWise(string currentPage);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllNotificationMasterPageWise/{currentPage}/{memberMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<NotificationMaster> SelectAllNotificationMasterPageWise(string currentPage, string memberMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllAdvertiseMasterPageWise/{currentPage}/{pageSize}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<AdvertiseMaster> SelectAllAdvertiseMasterPageWise(string currentPage, string pageSize);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllQualification", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<String> SelectAllQualification();

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllProfession", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<String> SelectAllProfession();

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllStates", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<String> SelectAllStates();

        [OperationContract]
        [WebGet(UriTemplate = "SendNotificationsToAll/{notificationMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        void SendNotificationsToAll(string notificationMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SendNotificationsNewRequest/{membermasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        void SendNotificationsNewRequest(string membermasterId);

        [OperationContract]
        [WebGet(UriTemplate = "ForgotPasswordMemberMaster/{email}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus ForgotPasswordMemberMaster(string email);


    }


}
